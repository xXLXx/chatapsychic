<?php
function prepend_url(){
	return "/";

}


function cms_prep(){
	return "/Applications/MAMP/htdocs/microsite_wrox/";
}

function target_prep(){
	return "/Applications/MAMP/htdocs/microsite_stage/";
}


function target_url(){
	return "http://localhost:8888/microsite_stage/";
}


?>