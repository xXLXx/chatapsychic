<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2015-09-04 13:57:55 --> Config Class Initialized
INFO - 2015-09-04 13:57:55 --> Hooks Class Initialized
DEBUG - 2015-09-04 13:57:55 --> UTF-8 Support Enabled
INFO - 2015-09-04 13:57:55 --> Utf8 Class Initialized
INFO - 2015-09-04 13:57:55 --> URI Class Initialized
INFO - 2015-09-04 13:57:55 --> Router Class Initialized
INFO - 2015-09-04 13:57:55 --> Output Class Initialized
INFO - 2015-09-04 13:57:55 --> Security Class Initialized
DEBUG - 2015-09-04 13:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-09-04 13:57:55 --> Input Class Initialized
INFO - 2015-09-04 13:57:55 --> Language Class Initialized
INFO - 2015-09-04 13:57:55 --> Loader Class Initialized
INFO - 2015-09-04 13:57:55 --> Helper loaded: url_helper
INFO - 2015-09-04 13:57:55 --> Helper loaded: cookie_helper
INFO - 2015-09-04 13:57:55 --> Database Driver Class Initialized
INFO - 2015-09-04 13:57:55 --> Session: Class initialized using 'database' driver.
INFO - 2015-09-04 13:57:55 --> Helper loaded: form_helper
INFO - 2015-09-04 13:57:55 --> Form Validation Class Initialized
INFO - 2015-09-04 13:57:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2015-09-04 13:57:55 --> Pagination Class Initialized
INFO - 2015-09-04 13:57:55 --> Encrypt Class Initialized
DEBUG - 2015-09-04 13:57:55 --> Tb class already loaded. Second attempt ignored.
INFO - 2015-09-04 13:57:55 --> Model Class Initialized
INFO - 2015-09-04 13:57:55 --> Model Class Initialized
INFO - 2015-09-04 13:57:55 --> Model Class Initialized
INFO - 2015-09-04 13:57:55 --> Controller Class Initialized
INFO - 2015-09-04 13:57:55 --> File loaded: /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/views/header.php
INFO - 2015-09-04 13:57:55 --> File loaded: /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/views/error_page.php
INFO - 2015-09-04 13:57:55 --> File loaded: /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/views/footer.php
INFO - 2015-09-04 13:57:55 --> Final output sent to browser
DEBUG - 2015-09-04 13:57:55 --> Total execution time: 0.1279
INFO - 2015-09-04 13:57:57 --> Config Class Initialized
INFO - 2015-09-04 13:57:57 --> Hooks Class Initialized
DEBUG - 2015-09-04 13:57:57 --> UTF-8 Support Enabled
INFO - 2015-09-04 13:57:57 --> Utf8 Class Initialized
INFO - 2015-09-04 13:57:57 --> URI Class Initialized
INFO - 2015-09-04 13:57:57 --> Router Class Initialized
INFO - 2015-09-04 13:57:57 --> Output Class Initialized
INFO - 2015-09-04 13:57:57 --> Security Class Initialized
DEBUG - 2015-09-04 13:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-09-04 13:57:57 --> Input Class Initialized
INFO - 2015-09-04 13:57:57 --> Language Class Initialized
INFO - 2015-09-04 13:57:57 --> Loader Class Initialized
INFO - 2015-09-04 13:57:57 --> Helper loaded: url_helper
INFO - 2015-09-04 13:57:57 --> Helper loaded: cookie_helper
INFO - 2015-09-04 13:57:57 --> Database Driver Class Initialized
INFO - 2015-09-04 13:57:57 --> Session: Class initialized using 'database' driver.
INFO - 2015-09-04 13:57:57 --> Helper loaded: form_helper
INFO - 2015-09-04 13:57:57 --> Form Validation Class Initialized
INFO - 2015-09-04 13:57:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2015-09-04 13:57:57 --> Pagination Class Initialized
INFO - 2015-09-04 13:57:57 --> Encrypt Class Initialized
DEBUG - 2015-09-04 13:57:57 --> Tb class already loaded. Second attempt ignored.
INFO - 2015-09-04 13:57:57 --> Model Class Initialized
INFO - 2015-09-04 13:57:57 --> Model Class Initialized
INFO - 2015-09-04 13:57:57 --> Model Class Initialized
INFO - 2015-09-04 13:57:57 --> Controller Class Initialized
INFO - 2015-09-04 13:57:57 --> File loaded: /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/views/header.php
INFO - 2015-09-04 13:57:57 --> File loaded: /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/views/error_page.php
INFO - 2015-09-04 13:57:57 --> File loaded: /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/views/footer.php
INFO - 2015-09-04 13:57:57 --> Final output sent to browser
DEBUG - 2015-09-04 13:57:57 --> Total execution time: 0.0713
INFO - 2015-09-04 14:00:44 --> Config Class Initialized
INFO - 2015-09-04 14:00:44 --> Hooks Class Initialized
DEBUG - 2015-09-04 14:00:44 --> UTF-8 Support Enabled
INFO - 2015-09-04 14:00:44 --> Utf8 Class Initialized
INFO - 2015-09-04 14:00:44 --> URI Class Initialized
INFO - 2015-09-04 14:00:44 --> Router Class Initialized
INFO - 2015-09-04 14:00:44 --> Output Class Initialized
INFO - 2015-09-04 14:00:44 --> Security Class Initialized
DEBUG - 2015-09-04 14:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-09-04 14:00:44 --> Input Class Initialized
INFO - 2015-09-04 14:00:44 --> Language Class Initialized
INFO - 2015-09-04 14:00:44 --> Loader Class Initialized
INFO - 2015-09-04 14:00:44 --> Helper loaded: url_helper
INFO - 2015-09-04 14:00:44 --> Helper loaded: cookie_helper
INFO - 2015-09-04 14:00:44 --> Database Driver Class Initialized
INFO - 2015-09-04 14:00:44 --> Session: Class initialized using 'database' driver.
INFO - 2015-09-04 14:00:44 --> Helper loaded: form_helper
INFO - 2015-09-04 14:00:44 --> Form Validation Class Initialized
INFO - 2015-09-04 14:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2015-09-04 14:00:44 --> Pagination Class Initialized
INFO - 2015-09-04 14:00:44 --> Encrypt Class Initialized
DEBUG - 2015-09-04 14:00:44 --> Tb class already loaded. Second attempt ignored.
INFO - 2015-09-04 14:00:44 --> Model Class Initialized
INFO - 2015-09-04 14:00:44 --> Model Class Initialized
INFO - 2015-09-04 14:00:44 --> Model Class Initialized
INFO - 2015-09-04 14:00:44 --> Controller Class Initialized
INFO - 2015-09-04 14:00:44 --> File loaded: /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/views/header.php
INFO - 2015-09-04 14:00:44 --> File loaded: /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/views/error_page.php
INFO - 2015-09-04 14:00:44 --> File loaded: /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/views/footer.php
INFO - 2015-09-04 14:00:44 --> Final output sent to browser
DEBUG - 2015-09-04 14:00:44 --> Total execution time: 0.0833
INFO - 2015-09-04 14:00:45 --> Config Class Initialized
INFO - 2015-09-04 14:00:45 --> Hooks Class Initialized
DEBUG - 2015-09-04 14:00:45 --> UTF-8 Support Enabled
INFO - 2015-09-04 14:00:45 --> Utf8 Class Initialized
INFO - 2015-09-04 14:00:45 --> URI Class Initialized
INFO - 2015-09-04 14:00:45 --> Router Class Initialized
INFO - 2015-09-04 14:00:45 --> Output Class Initialized
INFO - 2015-09-04 14:00:45 --> Security Class Initialized
DEBUG - 2015-09-04 14:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-09-04 14:00:45 --> Input Class Initialized
INFO - 2015-09-04 14:00:45 --> Language Class Initialized
INFO - 2015-09-04 14:00:45 --> Loader Class Initialized
INFO - 2015-09-04 14:00:45 --> Helper loaded: url_helper
INFO - 2015-09-04 14:00:45 --> Helper loaded: cookie_helper
INFO - 2015-09-04 14:00:45 --> Database Driver Class Initialized
INFO - 2015-09-04 14:00:45 --> Session: Class initialized using 'database' driver.
INFO - 2015-09-04 14:00:45 --> Helper loaded: form_helper
INFO - 2015-09-04 14:00:45 --> Form Validation Class Initialized
INFO - 2015-09-04 14:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2015-09-04 14:00:45 --> Pagination Class Initialized
INFO - 2015-09-04 14:00:45 --> Encrypt Class Initialized
DEBUG - 2015-09-04 14:00:45 --> Tb class already loaded. Second attempt ignored.
INFO - 2015-09-04 14:00:45 --> Model Class Initialized
INFO - 2015-09-04 14:00:45 --> Model Class Initialized
INFO - 2015-09-04 14:00:45 --> Model Class Initialized
INFO - 2015-09-04 14:00:45 --> Controller Class Initialized
INFO - 2015-09-04 14:00:45 --> File loaded: /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/views/header.php
INFO - 2015-09-04 14:00:45 --> File loaded: /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/views/error_page.php
INFO - 2015-09-04 14:00:45 --> File loaded: /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/views/footer.php
INFO - 2015-09-04 14:00:45 --> Final output sent to browser
DEBUG - 2015-09-04 14:00:45 --> Total execution time: 0.0784
ERROR - 2015-09-04 14:06:58 --> Severity: Notice --> Use of undefined constant is_manual - assumed 'is_manual' /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/models/Reader.php 155
ERROR - 2015-09-04 14:26:04 --> Severity: Warning --> require_once(/usr/home/sow/domains/dev2.psychic-contact.com/public_html/application//controllers/popup.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/controllers/chat/Main.php 3
ERROR - 2015-09-04 14:26:04 --> Severity: Compile Error --> require_once() [<a href='function.require'>function.require</a>]: Failed opening required '/usr/home/sow/domains/dev2.psychic-contact.com/public_html/application//controllers/popup.php' (include_path='.:/usr/local/php5/lib/php') /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/controllers/chat/Main.php 3
ERROR - 2015-09-04 14:28:17 --> Could not find the language line "form_validation_xss_clean"
ERROR - 2015-09-04 14:28:17 --> Could not find the language line "form_validation_xss_clean"
ERROR - 2015-09-04 14:28:17 --> Could not find the language line "form_validation_xss_clean"
ERROR - 2015-09-04 14:28:17 --> Could not find the language line "form_validation_xss_clean"
ERROR - 2015-09-04 14:28:17 --> Could not find the language line "form_validation_xss_clean"
ERROR - 2015-09-04 14:29:24 --> Could not find the language line "form_validation_xss_clean"
ERROR - 2015-09-04 14:29:24 --> Could not find the language line "form_validation_xss_clean"
ERROR - 2015-09-04 14:29:24 --> Could not find the language line "form_validation_xss_clean"
ERROR - 2015-09-04 15:58:27 --> Could not find the language line "form_validation_xss_clean"
ERROR - 2015-09-04 15:58:27 --> Could not find the language line "form_validation_xss_clean"
ERROR - 2015-09-04 15:58:27 --> Could not find the language line "form_validation_xss_clean"
ERROR - 2015-09-04 16:00:50 --> Could not find the language line "form_validation_ƒtrim"
