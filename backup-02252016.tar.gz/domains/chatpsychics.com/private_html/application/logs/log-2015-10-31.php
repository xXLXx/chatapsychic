<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-10-31 01:39:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-31 04:44:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-31 10:39:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-31 11:46:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-31 16:41:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-31 16:41:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-31 16:49:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-31 18:04:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-31 22:51:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
