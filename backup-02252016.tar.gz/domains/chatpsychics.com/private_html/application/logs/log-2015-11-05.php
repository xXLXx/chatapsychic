<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-05 15:30:19 --> Severity: Notice --> Undefined index: mobile_token /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 63
ERROR - 2015-11-05 15:30:19 --> Severity: Notice --> Undefined index: date_registered /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 64
ERROR - 2015-11-05 15:30:19 --> Severity: Notice --> Undefined index: date_registered /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 64
ERROR - 2015-11-05 15:30:19 --> Severity: Notice --> Undefined index: date_registered /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 64
ERROR - 2015-11-05 15:30:19 --> Severity: Notice --> Undefined index: last_payment_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 65
ERROR - 2015-11-05 15:30:19 --> Severity: Notice --> Undefined index: last_payment_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 65
ERROR - 2015-11-05 15:30:19 --> Severity: Notice --> Undefined index: last_payment_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 65
ERROR - 2015-11-05 15:30:19 --> Severity: Notice --> Undefined index: last_login_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 66
ERROR - 2015-11-05 15:30:19 --> Severity: Notice --> Undefined index: last_login_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 66
ERROR - 2015-11-05 15:30:19 --> Severity: Notice --> Undefined index: last_login_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 66
ERROR - 2015-11-05 15:30:36 --> Severity: Notice --> Undefined variable: content /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/pages/homepage.php 39
ERROR - 2015-11-05 15:43:04 --> Severity: Notice --> Undefined index: mobile_token /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 63
ERROR - 2015-11-05 15:43:04 --> Severity: Notice --> Undefined index: date_registered /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 64
ERROR - 2015-11-05 15:43:04 --> Severity: Notice --> Undefined index: date_registered /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 64
ERROR - 2015-11-05 15:43:04 --> Severity: Notice --> Undefined index: date_registered /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 64
ERROR - 2015-11-05 15:43:04 --> Severity: Notice --> Undefined index: last_payment_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 65
ERROR - 2015-11-05 15:43:04 --> Severity: Notice --> Undefined index: last_payment_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 65
ERROR - 2015-11-05 15:43:04 --> Severity: Notice --> Undefined index: last_payment_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 65
ERROR - 2015-11-05 15:43:04 --> Severity: Notice --> Undefined index: last_login_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 66
ERROR - 2015-11-05 15:43:04 --> Severity: Notice --> Undefined index: last_login_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 66
ERROR - 2015-11-05 15:43:04 --> Severity: Notice --> Undefined index: last_login_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 66
ERROR - 2015-11-05 15:43:12 --> Severity: Notice --> Undefined index: mobile_token /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 63
ERROR - 2015-11-05 15:43:12 --> Severity: Notice --> Undefined index: date_registered /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 64
ERROR - 2015-11-05 15:43:12 --> Severity: Notice --> Undefined index: date_registered /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 64
ERROR - 2015-11-05 15:43:12 --> Severity: Notice --> Undefined index: date_registered /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 64
ERROR - 2015-11-05 15:43:12 --> Severity: Notice --> Undefined index: last_payment_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 65
ERROR - 2015-11-05 15:43:12 --> Severity: Notice --> Undefined index: last_payment_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 65
ERROR - 2015-11-05 15:43:12 --> Severity: Notice --> Undefined index: last_payment_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 65
ERROR - 2015-11-05 15:43:12 --> Severity: Notice --> Undefined index: last_login_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 66
ERROR - 2015-11-05 15:43:12 --> Severity: Notice --> Undefined index: last_login_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 66
ERROR - 2015-11-05 15:43:12 --> Severity: Notice --> Undefined index: last_login_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 66
ERROR - 2015-11-05 15:44:54 --> Severity: Notice --> Undefined index: mobile_token /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 63
ERROR - 2015-11-05 15:44:54 --> Severity: Notice --> Undefined index: date_registered /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 64
ERROR - 2015-11-05 15:44:54 --> Severity: Notice --> Undefined index: date_registered /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 64
ERROR - 2015-11-05 15:44:54 --> Severity: Notice --> Undefined index: date_registered /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 64
ERROR - 2015-11-05 15:44:54 --> Severity: Notice --> Undefined index: last_payment_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 65
ERROR - 2015-11-05 15:44:54 --> Severity: Notice --> Undefined index: last_payment_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 65
ERROR - 2015-11-05 15:44:54 --> Severity: Notice --> Undefined index: last_payment_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 65
ERROR - 2015-11-05 15:44:54 --> Severity: Notice --> Undefined index: last_login_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 66
ERROR - 2015-11-05 15:44:54 --> Severity: Notice --> Undefined index: last_login_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 66
ERROR - 2015-11-05 15:44:54 --> Severity: Notice --> Undefined index: last_login_date /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/record_form.php 66
ERROR - 2015-11-05 16:36:23 --> Query error: Unknown column 'expert' in 'where clause' - Invalid query: SELECT profiles.* FROM members,profiles WHERE (first_name LIKE "%%" OR last_name LIKE "%%" OR members.id LIKE "%%") AND expert = 1 AND profiles.member_id = members.id 
ERROR - 2015-11-05 16:54:40 --> Severity: Notice --> Undefined index: directResponse /usr/home/tst8/domains/chatpsychics.com/public_html/application/libraries/Authcim.php 340
ERROR - 2015-11-05 16:54:41 --> Severity: Notice --> Undefined offset: 3 /usr/home/tst8/domains/chatpsychics.com/public_html/application/libraries/Authcim.php 346
ERROR - 2015-11-05 16:54:41 --> Severity: Notice --> Undefined index: directResponse /usr/home/tst8/domains/chatpsychics.com/public_html/application/libraries/Authcim.php 340
ERROR - 2015-11-05 16:54:41 --> Severity: Notice --> Undefined offset: 3 /usr/home/tst8/domains/chatpsychics.com/public_html/application/libraries/Authcim.php 346
ERROR - 2015-11-05 17:00:18 --> Severity: Parsing Error --> syntax error, unexpected ';' /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/pages/homepage.php 32
ERROR - 2015-11-05 17:00:20 --> Severity: Parsing Error --> syntax error, unexpected ';' /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/pages/homepage.php 32
