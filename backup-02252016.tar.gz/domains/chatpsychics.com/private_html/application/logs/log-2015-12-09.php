<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-09 02:51:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
