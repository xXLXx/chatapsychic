<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-13 00:22:15 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 00:22:15 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 00:22:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 00:22:15 --> Unable to select database: tst8_main
ERROR - 2015-12-13 00:22:46 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 00:22:46 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 00:22:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 00:22:46 --> Unable to select database: tst8_main
ERROR - 2015-12-13 01:11:12 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 01:11:12 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 01:11:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 01:11:12 --> Unable to select database: tst8_main
ERROR - 2015-12-13 01:11:52 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 01:11:52 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 01:11:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 01:11:52 --> Unable to select database: tst8_main
ERROR - 2015-12-13 01:18:58 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 01:18:58 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 01:18:58 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 01:18:58 --> Unable to select database: tst8_main
ERROR - 2015-12-13 01:21:59 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 01:21:59 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 01:21:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 01:21:59 --> Unable to select database: tst8_main
ERROR - 2015-12-13 02:00:30 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 02:00:30 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 02:00:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 02:00:30 --> Unable to select database: tst8_main
ERROR - 2015-12-13 02:01:11 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 02:01:11 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 02:01:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 02:01:11 --> Unable to select database: tst8_main
ERROR - 2015-12-13 02:20:35 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 02:20:35 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 02:20:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 02:20:35 --> Unable to select database: tst8_main
ERROR - 2015-12-13 02:23:13 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 02:23:13 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 02:23:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 02:23:13 --> Unable to select database: tst8_main
ERROR - 2015-12-13 03:02:59 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 03:02:59 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 03:02:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 03:02:59 --> Unable to select database: tst8_main
ERROR - 2015-12-13 03:03:52 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 03:03:52 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 03:03:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 03:03:52 --> Unable to select database: tst8_main
ERROR - 2015-12-13 03:22:17 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 03:22:17 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 03:22:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 03:22:17 --> Unable to select database: tst8_main
ERROR - 2015-12-13 03:23:33 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 03:23:33 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 03:23:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 03:23:33 --> Unable to select database: tst8_main
ERROR - 2015-12-13 04:22:31 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 04:22:31 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 04:22:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 04:22:31 --> Unable to select database: tst8_main
ERROR - 2015-12-13 04:39:45 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 04:39:45 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 04:39:45 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 04:39:45 --> Unable to select database: tst8_main
ERROR - 2015-12-13 04:40:08 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 04:40:08 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 04:40:08 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 04:40:08 --> Unable to select database: tst8_main
ERROR - 2015-12-13 05:22:09 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 05:22:09 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 05:22:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 05:22:09 --> Unable to select database: tst8_main
ERROR - 2015-12-13 05:23:07 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 05:23:07 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 05:23:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 05:23:07 --> Unable to select database: tst8_main
ERROR - 2015-12-13 06:17:49 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:17:49 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:17:49 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 06:17:49 --> Unable to select database: tst8_main
ERROR - 2015-12-13 06:19:24 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:19:24 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:19:24 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 06:19:24 --> Unable to select database: tst8_main
ERROR - 2015-12-13 06:23:11 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:23:11 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:23:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 06:23:11 --> Unable to select database: tst8_main
ERROR - 2015-12-13 06:24:18 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:24:18 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:24:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 06:24:18 --> Unable to select database: tst8_main
ERROR - 2015-12-13 06:25:08 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:25:08 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:25:08 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 06:25:08 --> Unable to select database: tst8_main
ERROR - 2015-12-13 06:42:55 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:42:55 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:42:55 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 06:42:55 --> Unable to select database: tst8_main
ERROR - 2015-12-13 06:43:15 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:43:15 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:43:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 06:43:15 --> Unable to select database: tst8_main
ERROR - 2015-12-13 06:44:34 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:44:34 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 06:44:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 06:44:34 --> Unable to select database: tst8_main
ERROR - 2015-12-13 07:22:31 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 07:22:31 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 07:22:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 07:22:31 --> Unable to select database: tst8_main
ERROR - 2015-12-13 07:22:45 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 07:22:45 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 07:22:45 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 07:22:45 --> Unable to select database: tst8_main
ERROR - 2015-12-13 07:45:53 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 07:45:53 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 07:45:53 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 07:45:53 --> Unable to select database: tst8_main
ERROR - 2015-12-13 07:46:27 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 07:46:27 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 07:46:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 07:46:27 --> Unable to select database: tst8_main
ERROR - 2015-12-13 08:01:00 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 08:01:01 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 08:01:01 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 08:01:01 --> Unable to select database: tst8_main
ERROR - 2015-12-13 08:22:35 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 08:22:35 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 08:22:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 08:22:35 --> Unable to select database: tst8_main
ERROR - 2015-12-13 09:02:39 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 09:02:39 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 09:02:39 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 09:02:39 --> Unable to select database: tst8_main
ERROR - 2015-12-13 09:03:41 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 09:03:41 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 09:03:41 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 09:03:41 --> Unable to select database: tst8_main
ERROR - 2015-12-13 09:16:00 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 09:16:00 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 09:16:00 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 09:16:00 --> Unable to select database: tst8_main
ERROR - 2015-12-13 09:26:20 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 09:26:20 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 09:26:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 09:26:20 --> Unable to select database: tst8_main
ERROR - 2015-12-13 09:51:55 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 09:51:55 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 09:51:55 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 09:51:55 --> Unable to select database: tst8_main
ERROR - 2015-12-13 09:52:29 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 09:52:29 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 09:52:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 09:52:29 --> Unable to select database: tst8_main
ERROR - 2015-12-13 10:16:55 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 10:16:55 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 10:16:55 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 10:16:55 --> Unable to select database: tst8_main
ERROR - 2015-12-13 10:25:09 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 10:25:09 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 10:25:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 10:25:09 --> Unable to select database: tst8_main
ERROR - 2015-12-13 10:43:43 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 10:43:43 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 10:43:43 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 10:43:43 --> Unable to select database: tst8_main
ERROR - 2015-12-13 10:44:11 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 10:44:11 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 10:44:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 10:44:11 --> Unable to select database: tst8_main
ERROR - 2015-12-13 10:52:32 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 10:52:32 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 10:52:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 10:52:32 --> Unable to select database: tst8_main
ERROR - 2015-12-13 11:21:07 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 11:21:07 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 11:21:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 11:21:07 --> Unable to select database: tst8_main
ERROR - 2015-12-13 11:23:47 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 11:23:47 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 11:23:47 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 11:23:47 --> Unable to select database: tst8_main
ERROR - 2015-12-13 11:30:01 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 11:30:01 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 11:30:01 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 11:30:01 --> Unable to select database: tst8_main
ERROR - 2015-12-13 11:52:18 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 11:52:18 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 11:52:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 11:52:18 --> Unable to select database: tst8_main
ERROR - 2015-12-13 12:00:25 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 12:00:25 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 12:00:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 12:00:25 --> Unable to select database: tst8_main
ERROR - 2015-12-13 12:22:22 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 12:22:22 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 12:22:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 12:22:22 --> Unable to select database: tst8_main
ERROR - 2015-12-13 12:37:51 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 12:37:51 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 12:37:51 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 12:37:51 --> Unable to select database: tst8_main
ERROR - 2015-12-13 12:38:05 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 12:38:05 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 12:38:05 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 12:38:05 --> Unable to select database: tst8_main
ERROR - 2015-12-13 12:50:16 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 12:50:16 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 12:50:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 12:50:16 --> Unable to select database: tst8_main
ERROR - 2015-12-13 13:16:59 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 13:16:59 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 13:16:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 13:16:59 --> Unable to select database: tst8_main
ERROR - 2015-12-13 13:17:17 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 13:17:17 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 13:17:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 13:17:17 --> Unable to select database: tst8_main
ERROR - 2015-12-13 13:20:02 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 13:20:02 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 13:20:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 13:20:02 --> Unable to select database: tst8_main
ERROR - 2015-12-13 13:23:00 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 13:23:00 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 13:23:00 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 13:23:00 --> Unable to select database: tst8_main
ERROR - 2015-12-13 13:50:16 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 13:50:16 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 13:50:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 13:50:16 --> Unable to select database: tst8_main
ERROR - 2015-12-13 14:22:37 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 14:22:37 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 14:22:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 14:22:37 --> Unable to select database: tst8_main
ERROR - 2015-12-13 14:25:09 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 14:25:09 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 14:25:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 14:25:09 --> Unable to select database: tst8_main
ERROR - 2015-12-13 15:24:08 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 15:24:08 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 15:24:08 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 15:24:08 --> Unable to select database: tst8_main
ERROR - 2015-12-13 15:25:48 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 15:25:48 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 15:25:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 15:25:48 --> Unable to select database: tst8_main
ERROR - 2015-12-13 15:44:43 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 15:44:43 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 15:44:43 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 15:44:43 --> Unable to select database: tst8_main
ERROR - 2015-12-13 15:45:10 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 15:45:10 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 15:45:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 15:45:10 --> Unable to select database: tst8_main
ERROR - 2015-12-13 16:19:35 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 16:19:36 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 16:19:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 16:19:36 --> Unable to select database: tst8_main
ERROR - 2015-12-13 16:25:52 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 16:25:52 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 16:25:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 16:25:52 --> Unable to select database: tst8_main
ERROR - 2015-12-13 16:40:50 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 16:40:50 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 16:40:50 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 16:40:50 --> Unable to select database: tst8_main
ERROR - 2015-12-13 16:41:08 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 16:41:08 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 16:41:08 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 16:41:08 --> Unable to select database: tst8_main
ERROR - 2015-12-13 16:42:16 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 16:42:16 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 16:42:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 16:42:16 --> Unable to select database: tst8_main
ERROR - 2015-12-13 17:21:48 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 17:21:48 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 17:21:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 17:21:48 --> Unable to select database: tst8_main
ERROR - 2015-12-13 17:23:53 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 17:23:53 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 17:23:53 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 17:23:53 --> Unable to select database: tst8_main
ERROR - 2015-12-13 17:38:50 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 17:38:50 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 17:38:50 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 17:38:50 --> Unable to select database: tst8_main
ERROR - 2015-12-13 17:39:07 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 17:39:07 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 17:39:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 17:39:07 --> Unable to select database: tst8_main
ERROR - 2015-12-13 17:40:41 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 17:40:41 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 17:40:41 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 17:40:41 --> Unable to select database: tst8_main
ERROR - 2015-12-13 18:23:14 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 18:23:14 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 18:23:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 18:23:14 --> Unable to select database: tst8_main
ERROR - 2015-12-13 18:24:36 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 18:24:36 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 18:24:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 18:24:36 --> Unable to select database: tst8_main
ERROR - 2015-12-13 18:34:38 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 18:34:38 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 18:34:38 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 18:34:38 --> Unable to select database: tst8_main
ERROR - 2015-12-13 19:23:26 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:23:26 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:23:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 19:23:26 --> Unable to select database: tst8_main
ERROR - 2015-12-13 19:25:36 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:25:36 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:25:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 19:25:36 --> Unable to select database: tst8_main
ERROR - 2015-12-13 19:38:27 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:38:27 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:38:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 19:38:27 --> Unable to select database: tst8_main
ERROR - 2015-12-13 19:44:38 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:44:38 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:44:38 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 19:44:38 --> Unable to select database: tst8_main
ERROR - 2015-12-13 19:45:13 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:45:13 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:45:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 19:45:13 --> Unable to select database: tst8_main
ERROR - 2015-12-13 19:52:29 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:52:29 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:52:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 19:52:29 --> Unable to select database: tst8_main
ERROR - 2015-12-13 19:52:44 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:52:44 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 19:52:44 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 19:52:44 --> Unable to select database: tst8_main
ERROR - 2015-12-13 20:23:13 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 20:23:13 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 20:23:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 20:23:13 --> Unable to select database: tst8_main
ERROR - 2015-12-13 20:24:39 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 20:24:39 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 20:24:39 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 20:24:39 --> Unable to select database: tst8_main
ERROR - 2015-12-13 20:56:10 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 20:56:10 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 20:56:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 20:56:10 --> Unable to select database: tst8_main
ERROR - 2015-12-13 20:57:07 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 20:57:07 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 20:57:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 20:57:07 --> Unable to select database: tst8_main
ERROR - 2015-12-13 21:22:26 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 21:22:26 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 21:22:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 21:22:26 --> Unable to select database: tst8_main
ERROR - 2015-12-13 21:26:18 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 21:26:18 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 21:26:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 21:26:18 --> Unable to select database: tst8_main
ERROR - 2015-12-13 21:45:21 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 21:45:21 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 21:45:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 21:45:21 --> Unable to select database: tst8_main
ERROR - 2015-12-13 21:45:52 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 21:45:52 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 21:45:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 21:45:52 --> Unable to select database: tst8_main
ERROR - 2015-12-13 21:47:49 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 21:47:49 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 21:47:49 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 21:47:49 --> Unable to select database: tst8_main
ERROR - 2015-12-13 21:47:50 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 21:47:50 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 21:47:50 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 21:47:50 --> Unable to select database: tst8_main
ERROR - 2015-12-13 22:07:11 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:07:11 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:07:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 22:07:11 --> Unable to select database: tst8_main
ERROR - 2015-12-13 22:22:38 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:22:38 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:22:38 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 22:22:38 --> Unable to select database: tst8_main
ERROR - 2015-12-13 22:25:51 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:25:51 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:25:51 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 22:25:51 --> Unable to select database: tst8_main
ERROR - 2015-12-13 22:36:27 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:36:27 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:36:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 22:36:27 --> Unable to select database: tst8_main
ERROR - 2015-12-13 22:36:34 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:36:34 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:36:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 22:36:34 --> Unable to select database: tst8_main
ERROR - 2015-12-13 22:42:09 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:42:09 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:42:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 22:42:09 --> Unable to select database: tst8_main
ERROR - 2015-12-13 22:42:35 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:42:35 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 22:42:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 22:42:35 --> Unable to select database: tst8_main
ERROR - 2015-12-13 23:23:24 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 23:23:24 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 23:23:24 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 23:23:24 --> Unable to select database: tst8_main
ERROR - 2015-12-13 23:25:37 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 23:25:37 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-13 23:25:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-13 23:25:37 --> Unable to select database: tst8_main
