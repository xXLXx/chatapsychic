<?php

    class Utils extends CI_Model{



    }