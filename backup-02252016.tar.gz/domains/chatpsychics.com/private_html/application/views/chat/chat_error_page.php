
	<div class='content_area'>
	
		<h2>Chat Not Found</h2>
		
		<p>The Chat session may be expired.  Please close this window and refresh your browser.</p>
	
	</div>