
	<div class='content_area'>
	
		<div class='pull-left' style='width:200px;'>
			
			<div class='btn-group btn-group-vertical' style='width:200px;'>
				<a href='/' class='btn btn-primary'>Fund My Account</a>
				<a href='/' class='btn btn-primary'>Select Your Reader</a>
				<a href='/' class='btn btn-primary'>Start Your Reading</a>
				<a href='/' class='btn btn-primary'>Message Center</a>
				<a href='/' class='btn btn-primary'>Chat History</a>
				<a href='/' class='btn btn-primary'>Purchases</a>
				<a href='/' class='btn btn-primary'>Page Reader</a>
				<a href='/' class='btn btn-primary'>Profile</a>
			</div>
		
		</div>
		
		<div class='pull-right' style='width:680px;'>
		
			<div class="content" style='padding-top:0;margin-top:0;'>
		
				<div class='well'>
				
					<div class='pull-left' style='width:40%;'>
					
						<h2 style='margin-top:10px;padding-top:0;line-height:0;'>Hi <?=$this->member['first_name']?> <?=$this->member['last_name']?></h2>
					
					</div>
					<div class='pull-right' style='width:50%;text-align:right;'>
					
						<h2 style='margin-top:10px;padding-top:0;line-height:0;font-size:14px;'>Chat Time Balance: <span style='color:#666;'>1.82 Minutes</span></h2>
					
					</div>
					<div class='clearfix'></div>
				
				</div>