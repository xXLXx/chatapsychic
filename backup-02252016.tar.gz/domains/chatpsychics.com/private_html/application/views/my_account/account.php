<div class="content-wrap">
    <div class="row ">
        <div class="col-md-8 content-main">
            <article>

                <div class='pull-left' style='width:200px;'>

                    <div class='btn-group btn-group-vertical' style='width:200px;'>

                        <?php
                        $unread = $this->messages_model->getUnreadMessages();
                        $badge = "";
                        if ($unread > 0)
                        {
                            $badge = "<span class=\"badge badge-important\" id=\"email-count\">{$unread}</span>";
                        }

                        // If expert, DON'T include some of the buttons
                        // They will not be neccessary

                        if ($this->member->data['member_type'] === 'reader')
                        {
                            echo "
                        <a href='/my_account' class='btn btn-primary " . ($this->uri->segment('2') == '' ? " active" : "") . "'>Dashboard</a>
                        <!--<a href='/my_account/transactions/fund_your_account' class='btn btn-primary " . ($this->uri->segment('3') == 'fund_your_account' ? " active" : "") . "'>Fund My Account</a>-->
                        <!--<a href='/my_account/main/nrr' class='btn btn-primary " . ($this->uri->segment('2') == 'main' ? " active" : "") . "'>NRR</a>-->
                        <!--<a href='/psychics' class='btn btn-primary'>Start Chat</a>-->
                        <!--<a href='/my_account/email_readings/client_emails' class='btn btn-primary " . ($this->uri->segment('2') == 'email_readings' ? " active" : "") . "'>My Email Readings</a>-->
                        <!--<a href='/my_account/chats' class='btn btn-primary " . ($this->uri->segment('2') == 'chats' ? " active" : "") . "'>Chat History</a>-->
                        <!--<a href='/my_account/favorites' class='btn btn-primary " . ($this->uri->segment('2') == 'favorites' ? " active" : "") . "'>My Favorite Readers</a>-->
                        <!--<a href='/my_account/transactions' class='btn " . ($this->uri->segment('2') == 'transactions' && $this->uri->segment('3') != 'fund_your_account' ? " active" : "") . "'>Billing & Transactions</a>-->
                        <a href='/my_account/messages' class='btn" . ($this->uri->segment('2') == 'messages' ? " active" : "") . "'>Message Center {$badge}</a>
                        <a href='/my_account/account' class='btn" . ($this->uri->segment('2') == 'account' ? " active" : "") . "'>Edit My Account</a>
                        <a href='/my_account/application' class='btn" . ($this->uri->segment('2') == 'application' ? " active" : "") . "'>Edit My Application</a>
						";
                        }
                        elseif ($this->member->data['member_type'] === 'affiliate')
                        {
                            echo "
                        <a href='/my_account' class='btn btn-primary " . ($this->uri->segment('2') == '' ? " active" : "") . "'>Dashboard</a>
                        <!--<a href='/my_account/transactions/fund_your_account' class='btn btn-primary " . ($this->uri->segment('3') == 'fund_your_account' ? " active" : "") . "'>Fund My Account</a>-->
                        <!--<a href='/my_account/main/nrr' class='btn btn-primary " . ($this->uri->segment('2') == 'main' ? " active" : "") . "'>NRR</a>-->
                        <!--<a href='/psychics' class='btn btn-primary'>Start Chat</a>-->
                        <!--<a href='/my_account/email_readings/client_emails' class='btn btn-primary " . ($this->uri->segment('2') == 'email_readings' ? " active" : "") . "'>My Email Readings</a>-->
                        <!--<a href='/my_account/chats' class='btn btn-primary " . ($this->uri->segment('2') == 'chats' ? " active" : "") . "'>Chat History</a>-->
                        <!--<a href='/my_account/favorites' class='btn btn-primary " . ($this->uri->segment('2') == 'favorites' ? " active" : "") . "'>My Favorite Readers</a>-->
                        <!--<a href='/my_account/transactions' class='btn " . ($this->uri->segment('2') == 'transactions' && $this->uri->segment('3') != 'fund_your_account' ? " active" : "") . "'>Billing & Transactions</a>-->
                        <a href='/my_account/messages' class='btn" . ($this->uri->segment('2') == 'messages' ? " active" : "") . "'>Message Center {$badge}</a>
                        <a href='/my_account/account' class='btn" . ($this->uri->segment('2') == 'account' ? " active" : "") . "'>Edit My Account</a>
						";
                        }
                        ?>

                    </div>

                </div>

                <div class='pull-right' style='width:520px;'>


                    <h2>Update My Account</h2>

                    <hr />

                    <form action='/my_account/account/save_account' method='POST' enctype="multipart/form-data">

                        <table width='100%' cellPadding='10' cellSpacing='0'>

                            <tr>
                                <td style='width:150px;'><b>Email Address:</b></td>
                                <td><?= $this->member->data['email'] ?></td>
                            </tr>

                            <tr>
                                <td style='width:150px;'><b>Username:</b></td>
                                <td><?= $this->member->data['username'] ?></td>
                            </tr>

                            <tr><td colSpan='2'><div style='color:#C0C0C0;'>Leave password fields blank to keep your current password</div></td></tr>

                            <tr>
                                <td style='width:150px;'><b>Choose A New Password:</b></td>
                                <td><input type='password' name='password' value='<?= set_value('password') ?>'></td>
                            </tr>

                            <tr>
                                <td style='width:150px;'><b>Re-Type New Password:</b></td>
                                <td><input type='password' name='password2' value='<?= set_value('password2') ?>'></td>
                            </tr>

                            <tr><td colSpan='2'><hr style='margin:10px 0;' /></td></tr>

                            <tr>
                                <td style='width:150px;'><b>First Name:</b> <span style='color:red;'>*</span></td>
                                <td><input type='text' name='first_name' value='<?= set_value('first_name', $this->member->data['first_name']) ?>'></td>
                            </tr>

                            <tr>
                                <td style='width:150px;'><b>Last Name:</b> <span style='color:red;'>*</span></td>
                                <td><input type='text' name='last_name' value='<?= set_value('last_name', $this->member->data['last_name']) ?>'></td>
                            </tr>

                            <tr>
                                <td style='width:150px;'><b>Gender:</b> <span style='color:red;'>*</span></td>
                                <td><div><input type='radio' name='gender' value='Male' <?= set_radio('gender', 'Male', ($this->member->data['gender'] == 'Male' ? TRUE : FALSE)) ?>> Male &nbsp; &nbsp; <input type='radio' name='gender' value='Female' <?= set_radio('gender', 'Female', ($this->member->data['gender'] == 'Female' ? TRUE : FALSE)) ?>> Female</div></td>
                            </tr>

                            <tr>
                                <td style='width:150px;'><b>Date of Birth:</b> <span style='color:red;'>*</span></td>
                                <td>
                                    <?

                                    list($dob_year,$dob_month,$dob_day)=explode("-", $this->member->data['dob']);
                                    echo $this->system_vars->dob_custom('dob', set_value('dob_month', $dob_month), set_value('dob_day', $dob_day), set_value('dob_year', $dob_year));

                                    ?>
                                </td>
                            </tr>

                            <tr>
                                <td style='width:150px;'><b>Country:</b> <span style='color:red;'>*</span></td>
                                <td><?= $this->system_vars->country_array_select_box('country', set_value('country', $this->member->data['country'])) ?></td>
                            </tr>

                            <tr><td colSpan='2'><hr style='margin:10px 0;' /></td></tr>

                            <tr>
                                <td style='width:150px;'><b>Profile Image:</b></td>
                                <td>

                                    <img src='<?= $this->member->data['profile_image'] ?>' style='border:solid 1px #000;'>

                                    <div style='padding:10px 0;color:#C0C0C0'>To keep your current profile image, leave the field below blank3</div>

                                    <input type='file' name='profile_image'>

                                </td>
                            </tr>


                            <tr><td colSpan='2'><hr style='margin:10px 0;' /></td></tr>

                            <tr>
                                <td>&nbsp;</td>
                                <td><input type='submit' name='submit' value='Save My Profile' class='btn btn-large btn-warning'></td>
                            </tr>

                        </table>

                    </form>

                </div>

            </article>

        </div>
        <div class="col-md-4">
            <aside>
                <section>
                    <div class="boxed">
                        <div class="border-wrap ">
                            <div class="top"></div>
                            <div class="mid">
                                <div class="inner">
                                    <h2>Apply as a reader</h2>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. </p>

                                </div>
                            </div>
                            <div class="footer-box">
                                <div class="box-btn"><a class="btn btn-primary btn-lg" href="#" role="button">View details</a></div>

                            </div>
                            <div class="curve"></div>
                        </div>
                    </div>
                </section>
                <section>
                    <div class="boxed">
                        <div class="border-wrap">
                            <div class="top"></div>
                            <div class="mid">
                                <div class="inner">
                                    <h2>Launch Your Own Psychic Site: <br/> at no cost to you!</h2>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>

                                </div>
                            </div>
                            <div class="footer-box">
                                <div class="box-btn"><a class="btn btn-primary btn-lg" href="#" role="button">View details</a></div>
                            </div>
                            <div class="curve"></div>
                        </div>
                    </div>
                </section>
                <section>
                    <div class="boxed">
                        <div class="border-wrap">
                            <div class="top"></div>
                            <div class="mid">
                                <div class="inner">
                                    <h2>Interested in both options?</h2>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>

                                </div>
                            </div>
                            <div class="footer-box">
                                <div class="box-btn"><a class="btn btn-primary btn-lg" href="#" role="button">View details</a></div>
                            </div>
                            <div class="curve"></div>

                        </div>
                    </div>
                </section>
            </aside>
        </div>
    </div>
</div>