<div class="content-wrap">
    <div class="row ">
        <div class="col-md-8 content-main">
            <article>

                <div class='pull-left' style='width:200px;'>

                    <div class='btn-group btn-group-vertical' style='width:200px;'>

                        <?php
                        $unread = $this->messages_model->getUnreadMessages();
                        $badge = "";
                        if ($unread > 0)
                        {
                            $badge = "<span class=\"badge badge-important\" id=\"email-count\">{$unread}</span>";
                        }

                        // If expert, DON'T include some of the buttons
                        // They will not be neccessary

                        if ($this->member->data['member_type'] === 'reader')
                        {
                            echo "
                        <a href='/my_account' class='btn btn-primary " . ($this->uri->segment('2') == '' ? " active" : "") . "'>Dashboard</a>
                        <!--<a href='/my_account/transactions/fund_your_account' class='btn btn-primary " . ($this->uri->segment('3') == 'fund_your_account' ? " active" : "") . "'>Fund My Account</a>-->
                        <!--<a href='/my_account/main/nrr' class='btn btn-primary " . ($this->uri->segment('2') == 'main' ? " active" : "") . "'>NRR</a>-->
                        <!--<a href='/psychics' class='btn btn-primary'>Start Chat</a>-->
                        <!--<a href='/my_account/email_readings/client_emails' class='btn btn-primary " . ($this->uri->segment('2') == 'email_readings' ? " active" : "") . "'>My Email Readings</a>-->
                        <!--<a href='/my_account/chats' class='btn btn-primary " . ($this->uri->segment('2') == 'chats' ? " active" : "") . "'>Chat History</a>-->
                        <!--<a href='/my_account/favorites' class='btn btn-primary " . ($this->uri->segment('2') == 'favorites' ? " active" : "") . "'>My Favorite Readers</a>-->
                        <!--<a href='/my_account/transactions' class='btn " . ($this->uri->segment('2') == 'transactions' && $this->uri->segment('3') != 'fund_your_account' ? " active" : "") . "'>Billing & Transactions</a>-->
                        <a href='/my_account/messages' class='btn" . ($this->uri->segment('2') == 'messages' ? " active" : "") . "'>Message Center {$badge}</a>
                        <a href='/my_account/account' class='btn" . ($this->uri->segment('2') == 'account' ? " active" : "") . "'>Edit My Account</a>
                        <a href='/my_account/application' class='btn" . ($this->uri->segment('2') == 'application' ? " active" : "") . "'>Edit My Application</a>
						";
                        }
                        elseif ($this->member->data['member_type'] === 'affiliate')
                        {
                            echo "
                        <a href='/my_account' class='btn btn-primary " . ($this->uri->segment('2') == '' ? " active" : "") . "'>Dashboard</a>
                        <!--<a href='/my_account/transactions/fund_your_account' class='btn btn-primary " . ($this->uri->segment('3') == 'fund_your_account' ? " active" : "") . "'>Fund My Account</a>-->
                        <!--<a href='/my_account/main/nrr' class='btn btn-primary " . ($this->uri->segment('2') == 'main' ? " active" : "") . "'>NRR</a>-->
                        <!--<a href='/psychics' class='btn btn-primary'>Start Chat</a>-->
                        <!--<a href='/my_account/email_readings/client_emails' class='btn btn-primary " . ($this->uri->segment('2') == 'email_readings' ? " active" : "") . "'>My Email Readings</a>-->
                        <!--<a href='/my_account/chats' class='btn btn-primary " . ($this->uri->segment('2') == 'chats' ? " active" : "") . "'>Chat History</a>-->
                        <!--<a href='/my_account/favorites' class='btn btn-primary " . ($this->uri->segment('2') == 'favorites' ? " active" : "") . "'>My Favorite Readers</a>-->
                        <!--<a href='/my_account/transactions' class='btn " . ($this->uri->segment('2') == 'transactions' && $this->uri->segment('3') != 'fund_your_account' ? " active" : "") . "'>Billing & Transactions</a>-->
                        <a href='/my_account/messages' class='btn" . ($this->uri->segment('2') == 'messages' ? " active" : "") . "'>Message Center {$badge}</a>
                        <a href='/my_account/account' class='btn" . ($this->uri->segment('2') == 'account' ? " active" : "") . "'>Edit My Account</a>
						";
                        }
                        ?>

                    </div>

                </div>

                <div class='pull-right' style='width:520px;'>
                    <div class='well'>
                        <div class='pull-left' style='width:445px;'>
                            <div class="pull-left" style="width:100px;">
                                <div align="center">
                                    <a href='/my_account/account' style="font-size:11px;"><img src="<?= $this->member->data['profile_image'] ?>" class="img-polaroid" width="75" /></a>
                                    <div><a href='/my_account/account' style="font-size:11px;">Change Image</a></div>
                                </div>
                            </div>
                            <div class="pull-left" style="width:250px;margin-left:10px;">
                                <h2 style='margin-top:10px;padding-top:10px;line-height:0;'>Hi <?= $this->member->data['first_name'] ?> <?= $this->member->data['last_name'] ?></h2>
                                <span>Username: <?= $this->member->data['username'] ?></span>
                            </div>
                            <div class="clearfix"></div>

                        </div>
                        <div class='pull-right' style='width:190px;text-align:right;'>        
                            <?php if ($this->member->data['member_type'] !== "affiliate"): ?>
                                <div style='margin:10px 0 0;'>
                                    <h4>Status: <?= ucwords($this->member->data['application_status']); ?></h4>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class='clearfix'></div>
                    </div>
                    
                    <?=$gallery;?>
                    
                </div>

            </article>

        </div>
        <div class="col-md-4">
            <aside>
                <section>
                    <div class="boxed">
                        <div class="border-wrap ">
                            <div class="top"></div>
                            <div class="mid">
                                <div class="inner">
                                    <h2>Apply as a reader</h2>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. </p>

                                </div>
                            </div>
                            <div class="footer-box">
                                <div class="box-btn"><a class="btn btn-primary btn-lg" href="#" role="button">View details</a></div>

                            </div>
                            <div class="curve"></div>
                        </div>
                    </div>
                </section>
                <section>
                    <div class="boxed">
                        <div class="border-wrap">
                            <div class="top"></div>
                            <div class="mid">
                                <div class="inner">
                                    <h2>Launch Your Own Psychic Site: <br/> at no cost to you!</h2>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>

                                </div>
                            </div>
                            <div class="footer-box">
                                <div class="box-btn"><a class="btn btn-primary btn-lg" href="#" role="button">View details</a></div>
                            </div>
                            <div class="curve"></div>
                        </div>
                    </div>
                </section>
                <section>
                    <div class="boxed">
                        <div class="border-wrap">
                            <div class="top"></div>
                            <div class="mid">
                                <div class="inner">
                                    <h2>Interested in both options?</h2>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>

                                </div>
                            </div>
                            <div class="footer-box">
                                <div class="box-btn"><a class="btn btn-primary btn-lg" href="#" role="button">View details</a></div>
                            </div>
                            <div class="curve"></div>

                        </div>
                    </div>
                </section>
            </aside>
        </div>
    </div>
</div>