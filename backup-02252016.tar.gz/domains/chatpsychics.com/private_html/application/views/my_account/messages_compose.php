<div class="content-wrap">
    <div class="row ">
        <div class="col-md-8 content-main">
            <article>

                <div class='pull-left' style='width:200px;'>

                    <div class='btn-group btn-group-vertical' style='width:200px;'>

                        <?php
                        $unread = $this->messages_model->getUnreadMessages();
                        $badge = "";
                        if ($unread > 0)
                        {
                            $badge = "<span class=\"badge badge-important\" id=\"email-count\">{$unread}</span>";
                        }

                        // If expert, DON'T include some of the buttons
                        // They will not be neccessary

                        if ($this->member->data['member_type'] === 'reader')
                        {
                            echo "
                        <a href='/my_account' class='btn btn-primary " . ($this->uri->segment('2') == '' ? " active" : "") . "'>Dashboard</a>
                        <!--<a href='/my_account/transactions/fund_your_account' class='btn btn-primary " . ($this->uri->segment('3') == 'fund_your_account' ? " active" : "") . "'>Fund My Account</a>-->
                        <!--<a href='/my_account/main/nrr' class='btn btn-primary " . ($this->uri->segment('2') == 'main' ? " active" : "") . "'>NRR</a>-->
                        <!--<a href='/psychics' class='btn btn-primary'>Start Chat</a>-->
                        <!--<a href='/my_account/email_readings/client_emails' class='btn btn-primary " . ($this->uri->segment('2') == 'email_readings' ? " active" : "") . "'>My Email Readings</a>-->
                        <!--<a href='/my_account/chats' class='btn btn-primary " . ($this->uri->segment('2') == 'chats' ? " active" : "") . "'>Chat History</a>-->
                        <!--<a href='/my_account/favorites' class='btn btn-primary " . ($this->uri->segment('2') == 'favorites' ? " active" : "") . "'>My Favorite Readers</a>-->
                        <!--<a href='/my_account/transactions' class='btn " . ($this->uri->segment('2') == 'transactions' && $this->uri->segment('3') != 'fund_your_account' ? " active" : "") . "'>Billing & Transactions</a>-->
                        <a href='/my_account/messages' class='btn" . ($this->uri->segment('2') == 'messages' ? " active" : "") . "'>Message Center {$badge}</a>
                        <a href='/my_account/account' class='btn" . ($this->uri->segment('2') == 'account' ? " active" : "") . "'>Edit My Account</a>
                        <a href='/my_account/application' class='btn" . ($this->uri->segment('2') == 'application' ? " active" : "") . "'>Edit My Application</a>
						";
                        }
                        elseif ($this->member->data['member_type'] === 'affiliate')
                        {
                            echo "
                        <a href='/my_account' class='btn btn-primary " . ($this->uri->segment('2') == '' ? " active" : "") . "'>Dashboard</a>
                        <!--<a href='/my_account/transactions/fund_your_account' class='btn btn-primary " . ($this->uri->segment('3') == 'fund_your_account' ? " active" : "") . "'>Fund My Account</a>-->
                        <!--<a href='/my_account/main/nrr' class='btn btn-primary " . ($this->uri->segment('2') == 'main' ? " active" : "") . "'>NRR</a>-->
                        <!--<a href='/psychics' class='btn btn-primary'>Start Chat</a>-->
                        <!--<a href='/my_account/email_readings/client_emails' class='btn btn-primary " . ($this->uri->segment('2') == 'email_readings' ? " active" : "") . "'>My Email Readings</a>-->
                        <!--<a href='/my_account/chats' class='btn btn-primary " . ($this->uri->segment('2') == 'chats' ? " active" : "") . "'>Chat History</a>-->
                        <!--<a href='/my_account/favorites' class='btn btn-primary " . ($this->uri->segment('2') == 'favorites' ? " active" : "") . "'>My Favorite Readers</a>-->
                        <!--<a href='/my_account/transactions' class='btn " . ($this->uri->segment('2') == 'transactions' && $this->uri->segment('3') != 'fund_your_account' ? " active" : "") . "'>Billing & Transactions</a>-->
                        <a href='/my_account/messages' class='btn" . ($this->uri->segment('2') == 'messages' ? " active" : "") . "'>Message Center {$badge}</a>
                        <a href='/my_account/account' class='btn" . ($this->uri->segment('2') == 'account' ? " active" : "") . "'>Edit My Account</a>
						";
                        }
                        ?>

                    </div>

                </div>

                <div class='pull-right' style='width:520px;'>

                    <div style='padding-bottom:25px;'>
                        <h2>Compose A New Message</h2>
                    </div>

                    <ul class="nav nav-tabs">
                        <li <?= ($this->uri->segment('3') == '' ? " class=\"active\"" : "") ?>><a href="/my_account/messages">Inbox</a></li>
                        <li <?= ($this->uri->segment('3') == 'outbox' ? " class=\"active\"" : "") ?>><a href="/my_account/messages/outbox">Outbox</a></li>
                        <li <?= ($this->uri->segment('3') == 'compose' ? " class=\"active\"" : "") ?>><a href="/my_account/messages/compose"><span class='icon icon-comment'></span> Compose A New Message</a></li>
                    </ul>

                    <form action='/my_account/messages/compose_submit' method='POST'>

                        <table width='100%' cellPadding='10'>

                            <tr>
                                <td width='150'><b>Recipient:</b></td>
                                <td>
                                    <?php
                                    if ($this->uri->segment('4'))
                                    {

                                        echo "User: #{$to} <input type='hidden' name='to' value='{$to}' class='input-mini'>";
                                    }
                                    else
                                    {

                                        echo "
							<select name='to'>
								<option value=''></option>";

                                        foreach ($users as $u)
                                        {

                                            echo "<option value='{$u['id']}'" . set_select('to', $u['id'], ($to == $u['id'] ? TRUE : FALSE)) . ">{$u['username']}</option>";
                                        }

                                        echo "
							</select>
							";
                                    }
                                    ?>

                                </td>
                            </tr>

                            <tr>
                                <td width='150'><b>Subject:</b></td>
                                <td><input type='text' name='subject' value='<?= set_value('subject', $subject) ?>'></td>
                            </tr>

                            <tr>
                                <td width='150'><b>Message:</b></td>
                                <td><textarea name='message' style='width:100%;height:150px;'><?= set_value('message', $message) ?></textarea></td>
                            </tr>

                            <tr>
                                <td width='150'>&nbsp;</td>
                                <td><input type='submit' name='submit' value='Send Message' class='btn btn-large btn-primary'></td>
                            </tr>

                        </table>

                    </form>

                </div>

            </article>

        </div>
        <div class="col-md-4">
            <aside>
                <section>
                    <div class="boxed">
                        <div class="border-wrap ">
                            <div class="top"></div>
                            <div class="mid">
                                <div class="inner">
                                    <h2>Apply as a reader</h2>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. </p>

                                </div>
                            </div>
                            <div class="footer-box">
                                <div class="box-btn"><a class="btn btn-primary btn-lg" href="#" role="button">View details</a></div>

                            </div>
                            <div class="curve"></div>
                        </div>
                    </div>
                </section>
                <section>
                    <div class="boxed">
                        <div class="border-wrap">
                            <div class="top"></div>
                            <div class="mid">
                                <div class="inner">
                                    <h2>Launch Your Own Psychic Site: <br/> at no cost to you!</h2>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>

                                </div>
                            </div>
                            <div class="footer-box">
                                <div class="box-btn"><a class="btn btn-primary btn-lg" href="#" role="button">View details</a></div>
                            </div>
                            <div class="curve"></div>
                        </div>
                    </div>
                </section>
                <section>
                    <div class="boxed">
                        <div class="border-wrap">
                            <div class="top"></div>
                            <div class="mid">
                                <div class="inner">
                                    <h2>Interested in both options?</h2>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>

                                </div>
                            </div>
                            <div class="footer-box">
                                <div class="box-btn"><a class="btn btn-primary btn-lg" href="#" role="button">View details</a></div>
                            </div>
                            <div class="curve"></div>

                        </div>
                    </div>
                </section>
            </aside>
        </div>
    </div>
</div>