
	<div class='content_area'>
	
		Category information coming…
	
	</div>