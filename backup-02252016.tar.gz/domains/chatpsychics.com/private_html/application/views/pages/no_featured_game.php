
	<div style='padding:100px 0;font-size:18px;font-weight:bold;color:#C0C0C0;' align='center'>There is currently no featured game</div>