
	<div class='content_area'>
		
		<h2><?=$title?></h2>
		<div class='caption' style='font-size:14px;'><?=date("F d, Y @ h:i A", strtotime($datetime))?> EST</div>
		
		<hr />
		
		<div style='line-height:24px;font-size:15px;'><?=nl2br($content)?></div>
	
	</div>