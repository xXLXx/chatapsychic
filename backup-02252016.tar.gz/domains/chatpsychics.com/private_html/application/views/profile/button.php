
    var username = '<?=$username?>';
