
	<div class='content_area'>
	
		<h1>Login Error</h1>
		
		<p>You have entered an invalid site id. Please contact the administrator for assistance.</p>
		
	</div>