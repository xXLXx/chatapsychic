<script src='https://www.google.com/recaptcha/api.js'></script>

<div class='content_area'>

    <h2>Reader - Application</h2>

    <div style='font-style:italic;'>Please enter the following information. Your information will be kept completely confidential. </div>

    <div style='margin:15px 0 0;'>Required fields are indicated with a red asterisk (<span style='color:red;'>*</span>) </div>

    <hr />

    <form action='/register/reader_submit' id="applicant-form" method='POST'>

        <table width='100%' cellPadding='10' cellSpacing='0'>

            <tr>
                <td style="width: 350px"><b>Username:</b> <span style='color:red;'>*</span></td>
                <td><input type='text' name='username' value='<?= set_value('username') ?>'></td>
            </tr>

            <tr>
                <td><b>Password:</b> <span style='color:red;'>*</span></td>
                <td><input type='password' name='password' value='<?= set_value('password') ?>'></td>
            </tr>

            <tr>
                <td><b>Re-Type Password:</b> <span style='color:red;'>*</span></td>
                <td><input type='password' name='password2' value='<?= set_value('password2') ?>'></td>
            </tr>

            <tr>
                <td><b>First Name:</b> <span style='color:red;'>*</span></td>
                <td><input type='text' name='first_name' value='<?= set_value('first_name') ?>'></td>
            </tr>

            <tr>
                <td><b>Last Name:</b> <span style='color:red;'>*</span></td>
                <td><input type='text' name='last_name' value='<?= set_value('last_name') ?>'></td>
            </tr>

            <tr>
                <td><b>Address Line 1:</b></td>
                <td><input type='text' name='address1' value='<?= set_value('address1') ?>'></td>
            </tr>
            <tr>
                <td><b>Address Line 2:</b></td>
                <td><input type='text' name='address2' value='<?= set_value('address2') ?>'></td>
            </tr>
            <tr>
                <td><b>City/Town:</b></td>
                <td><input type='text' name='city' value='<?= set_value('city') ?>'></td>
            </tr>
            <tr>
                <td><b>State/Province:</b></td>
                <td><input type='text' name='state' value='<?= set_value('state') ?>'></td>
            </tr>
            <tr>
                <td><b>Zip/Postal Code:</b></td>
                <td><input type='text' name='zip' value='<?= set_value('zip') ?>'></td>
            </tr>

            <tr>
                <td><b>Country:</b> <span style='color:red;'>*</span></td>
                <td><?= $this->system_vars->country_array_select_box('country', set_value('country')) ?></td>
            </tr>
            <tr>
                <td><b>Email Address:</b> <span style='color:red;'>*</span></td>
                <td><input type='text' name='email' value='<?= set_value('email') ?>'></td>
            </tr>
            <tr>
                <td><b>Phone Number:</b> <span style='color:red;'>*</span></td>
                <td><input type='text' name='phone' value='<?= set_value('phone') ?>'></td>
            </tr>
            <tr>
                <td><b>Date of Birth:</b> <span style='color:red;'>*</span></td>
                <td><?= $this->system_vars->dob_custom('dob', set_value('dob_month'), set_value('dob_day'), set_value('dob_year')) ?></td>
            </tr>
            <tr>
                <td><b>SSN/SIN#:</b> (If so, we will ask for it later) <span style='color:red;'>*</span></td>
                <td>
                    <input type='radio' name='ssn' value='N' <?= set_radio('ssn', 'N'); ?>> No &nbsp;
                    <input type='radio' name='ssn' value='Y' <?= set_radio('ssn', 'Y'); ?>> Yes
                </td>
            </tr>
            <tr>
                <td><b>Are you a U.S. resident?:</b> (If so, we will ask for it later) <span style='color:red;'>*</span></td>
                <td>
                    <input type='radio' name='us_resident' value='N' <?= set_radio('us_resident', 'N'); ?>> No &nbsp;
                    <input type='radio' name='us_resident' value='Y' <?= set_radio('us_resident', 'Y'); ?>> Yes
                </td>
            </tr>
            <tr>
                <td><b>Gender:</b> <span style='color:red;'>*</span></td>
                <td>
                    <div>
                        <input type='radio' name='gender' value='Male' <?= set_radio('gender', 'Male') ?>> Male &nbsp; &nbsp; 
                        <input type='radio' name='gender' value='Female' <?= set_radio('gender', 'Female') ?>> Female
                    </div>
                </td>
            </tr>


            <tr>
                <td colspan="2"><h2>Your Computer / Internet / Technical Information </h2></td>
            </tr>
            <tr>
                <td><b>Who is your ISP? (Internet Service Provider):</b></td>
                <td><input type='text' name='isp' value='<?= set_value('isp') ?>'></td>
            </tr>
            <tr>
                <td><b>How old is your Computer:</b></td>
                <td><input type='text' name='pc_age' style="width:5%" value='<?= set_value('pc_age') ?>'>/years</td>
            </tr>
            <tr>
                <td><b>Operating System:</b></td>
                <td><input type='text' name='os' value='<?= set_value('os') ?>'></td>
            </tr>
            <tr>
                <td>
                    <b>Do you read and write English fluently?:</b>
                    (This website supports the English language only. Applicants who require translation software
                    will not be considered.)
                </td>
                <td><input type='checkbox' name='en_fluent' value='Y' <?= set_checkbox('en_fluent', 'Y') ?>> Yes, I am fluent in English</td>
            </tr>

            <tr>
                <td><b>Please rate your grammar and communication skills:</b></td>
                <td>
                    <input type='radio' name='com_skills' value='1' <?= set_radio('com_skills', '1'); ?>> 1 (Low)
                    <input type='radio' name='com_skills' value='2' <?= set_radio('com_skills', '2'); ?>> 2 (Ok)
                    <input type='radio' name='com_skills' value='3' <?= set_radio('com_skills', '3'); ?>> 3 (Good)
                    <input type='radio' name='com_skills' value='4' <?= set_radio('com_skills', '4'); ?>> 4 (Great)
                    <input type='radio' name='com_skills' value='5' <?= set_radio('com_skills', '5'); ?>> 5 (Excellent)
                </td>            
            </tr>
            <tr>
                <td><b>Do you type at least 60 words per minute accurately?:</b></td>
                <td>
                    <input type='radio' name='typing_skills' value='N' <?= set_radio('typing_skills', 'N'); ?>> No
                    <input type='radio' name='typing_skills' value='Y' <?= set_radio('typing_skills', 'Y'); ?>> Yes
                </td>
            </tr>
            <tr>
                <td><b>Are you able to commit to a minimum of 15 hours per week?:</b></td>
                <td>
                    <input type='radio' name='is_committed' value='N' <?= set_radio('is_committed', 'N'); ?>> No
                    <input type='radio' name='is_committed' value='Y' <?= set_radio('is_committed', 'Y'); ?>> Yes
                </td>
            </tr>
            <tr>
                <td><b>Date Available For Starting Work?:</b></td>
                <td>
                    <input type='checkbox' name='date_avail[]' value='mon' <?= set_checkbox('date_avail[]', 'mon'); ?>> Mondays
                    <input type='checkbox' name='date_avail[]' value='tue' <?= set_checkbox('date_avail[]', 'tue'); ?>> Tuesdays
                    <input type='checkbox' name='date_avail[]' value='wed' <?= set_checkbox('date_avail[]', 'wed'); ?>> Wednesdays
                    <input type='checkbox' name='date_avail[]' value='thu' <?= set_checkbox('date_avail[]', 'thu'); ?>> Thursdays
                    <input type='checkbox' name='date_avail[]' value='fri' <?= set_checkbox('date_avail[]', 'fri'); ?>> Fridays
                    <input type='checkbox' name='date_avail[]' value='sat' <?= set_checkbox('date_avail[]', 'sat'); ?>> Saturdays
                    <input type='checkbox' name='date_avail[]' value='sun' <?= set_checkbox('date_avail[]', 'sun'); ?>> Sundays
                </td>
            </tr>

            <tr>
                <td colspan="2"><h2>Your Qualifications </h2></td>
            </tr>
            <tr>
                <td>
                    <b>Languages | Speak:</b> (Do you read / write English fluently? 
                    This website supports the English language only. Applicants who require translation
                    software will not be considered.)
                </td>
                <td><input type='text' name='languages' value='<?= set_value('languages') ?>'></td>
            </tr>
            <tr>
                <td><b>Areas of Expertise:</b></td>
                <td>
                    <input type='checkbox' name='expertise[]' value='Love / Romance / Relationship Advice' <?= set_checkbox('expertise[]', 'Love / Romance / Relationship Advice'); ?>> Love / Romance / Relationship Advice <br />
                    <input type='checkbox' name='expertise[]' value='Career / Finance / Money Advice' <?= set_checkbox('expertise[]', 'Career / Finance / Money Advice'); ?>> Career / Finance / Money Advice <br />
                    <input type='checkbox' name='expertise[]' value='Tarot Cart Readings' <?= set_checkbox('expertise[]', 'Tarot Cart Readings'); ?>> Tarot Cart Readings <br />
                    <input type='checkbox' name='expertise[]' value='Animal Communication' <?= set_checkbox('expertise[]', 'Animal Communication'); ?>> Animal Communication <br />
                    <input type='checkbox' name='expertise[]' value='Any Holistic Therapies' <?= set_checkbox('expertise[]', 'Any Holistic Therapies'); ?>> Any Holistic Therapies <br />
                    <input type='checkbox' name='expertise[]' value='Angels / Guides' <?= set_checkbox('expertise[]', 'Angels / Guides'); ?>> Angels / Guides <br />
                    <input type='checkbox' name='expertise[]' value='Channeling / Mediumship' <?= set_checkbox('expertise[]', 'Channeling / Mediumship'); ?>> Channeling / Mediumship <br />
                    <input type='checkbox' name='expertise[]' value='Dream Interpretation' <?= set_checkbox('expertise[]', 'Dream Interpretation'); ?>> Dream Interpretation <br />
                    <input type='checkbox' name='expertise[]' value='Past Life Analysis' <?= set_checkbox('expertise[]', 'Past Life Analysis'); ?>> Past Life Analysis <br />
                    <input type='checkbox' name='expertise[]' value='Numerology' <?= set_checkbox('expertise[]', 'Numerology'); ?>> Numerology <br />
                    <input type='checkbox' name='expertise[]' value='Astrology / Horoscopes' <?= set_checkbox('expertise[]', 'Astrology / Horoscopes'); ?>> Astrology / Horoscopes <br />
                </td>
            </tr>
            <tr>
                <td><b>Have you given Email Readings previously?:</b></td>
                <td>
                    <input type='radio' name='has_prev_readings' value='N' <?= set_radio('has_prev_readings', 'N'); ?>> No
                    <input type='radio' name='has_prev_readings' value='Y' <?= set_radio('has_prev_readings', 'Y'); ?>> Yes
                </td>
            </tr>
            <tr>
                <td><b>List All Your Skills:</b></td>
                <td>
                    <textarea name="skills"><?= set_value('skills'); ?></textarea>
                </td>
            </tr>
            <tr>
                <td><b>What forms of divination do you practice?:</b> (List all applicable)</td>
                <td>
                    <textarea name="divine_practices"><?= set_value('divine_practices'); ?></textarea>
                </td>
            </tr>

            <tr>
                <td colspan="2"><h2>Your Experience </h2></td>
            </tr>
            <tr>
                <td><b>Years of Reading Experience:</b> <span style='color:red;'>*</span></td>
                <td><input type='text' name='exp_years' style="width:5%" value='<?= set_value('exp_years') ?>'> years</td>
            </tr>
            <tr>
                <td>
                    <b>Companies Worked For:</b> PLEASE TELL US THE COMPANY NAMES (List all please)
                    WITH THE NAME THE CLIENTS KNEW YOU AS: examples: [format = Company\Your name]
                    which means enter your info like this: "Psychic Contact "Joe Light", 
                    TarotQuest "Stargazer", Psychicfair "Suzie", etc.
                </td>
                <td>
                    <textarea name="companies"><?= set_value('companies'); ?></textarea>
                </td>
            </tr>

            <tr>
                <td colspan="2"><h2>Articles / Blogs </h2></td>
            </tr>

            <tr>
                <td style='width:150px;'>
                    "PLEASE ENTER YOUR ARTICLE(s) or Furnish us with links on the web to your
                    blog(s) and/or actual articles written by you (This cannot be left blank):
                </td>
                <td>
                    <textarea name="articles"><?= set_value('articles'); ?></textarea>
                </td>
            </tr>
            <tr>
                <td>
                    Add anything else here that you think we may need to know about you:
                </td>
                <td>
                    <textarea name="bio"><?= set_value('bio'); ?></textarea>
                </td>
            </tr>

            <tr>
                <td><b>Captcha:</b> <span style='color:red;'>*</span></td>
                <td><div class="g-recaptcha" data-sitekey="6LceAxATAAAAAJyJPqyNm-ewf0sroy1fI8_THSYb"></div></td>
            </tr>

            <tr><td colSpan='2'><hr style='margin:10px 0;' /></td></tr>

            <tr>
                <td>&nbsp;</td>
                <td>
                    By clicking the "Submit Now" button you are attesting to the accuracy and truthfulness of the information you have entered. Any inaccurate information or false statements will result in immediate termination if you are hired.
                </td>
            </tr>

            <tr>
                <td>&nbsp;</td>
                <td><input type="button" value="Submit Now" class='btn btn-primary btn-large' id="btn-submit"></td>
            </tr>

        </table>
        <input type="hidden" name="status" value="pending" />

    </form>

</div>

<!-- include the style -->
<link rel="stylesheet" href="/media/javascript/alertify/css/alertify.css" />
<link rel="stylesheet" href="/media/javascript/alertify/css/themes/bootstrap.min.css" />
<!-- include the script -->
<script src="/media/javascript/alertify/alertify.min.js"></script>

<script>
    $(document).ready(function () {

        $("#btn-submit").click(function () {

            var dates_avail = new Array();
            $('input:checkbox[name="date_avail[]"]:checked').each(function ()
            {
                dates_avail.push($(this).val());
            });

            var areas_expertise = new Array();
            $('input:checkbox[name="expertise[]"]:checked').each(function ()
            {
                areas_expertise.push($(this).val());
            });

            var applicant = {
                "isp": $("input[name='isp']").val(),
                "pc_age": $("input[name='pc_age']").val(),
                "os": $("input[name='os']").val(),
                "en_fluent": $("input[name='en_fluent']").is(":checked") ? "Y" : "N",
                "grammar_rate": $("input[name='com_skills']:checked").val(),
                "typing_skills": $("input[name='typing_skills']:checked").val(),
                "is_committed": $("input[name='is_committed']:checked").val(),
                "date_availability": dates_avail,
                "spoken_languages": $("input[name='languages']").val(),
                "areas_of_expertise": areas_expertise,
                "has_prev_readings": $("input[name='has_prev_readings']:checked").val(),
                "no_of_years": $("input[name='exp_years']").val()
            };

            $.ajax({
                url: '/register/checkSettings',
                data: {applicant: applicant},
                type: 'post',
                dataType: 'json',
                success: function (data) {
                    if (data.application_status === "rejected") {
                        var msg = data.reject_reasons;
                        alertify.confirm('You might be rejected!', msg, function () {
                            $('input[name="status"]').val("rejected");
                            $("#applicant-form").submit();
                        }, function () {
                            ;
                        }).setting('labels', {'ok': 'Continue', 'cancel': 'Cancel'});
                        $(".ajs-header").addClass("btn-danger");
                        $(".ajs-header").css("color", "white");
                        $(".ajs-button.ajs-ok").addClass("btn btn-danger");
                        $(".ajs-button.ajs-cancel").addClass("btn btn-default");
                    } else {
                        $("#applicant-form").submit();
                    }
                },
                error: function () {
                    ;
                }
            });
        });


    });
</script>