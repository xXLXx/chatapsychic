
<div class='content_area'>

    <h2><?= $title ?></h2>

    <hr />

    <?= html_entity_decode($content) ?>

</div>