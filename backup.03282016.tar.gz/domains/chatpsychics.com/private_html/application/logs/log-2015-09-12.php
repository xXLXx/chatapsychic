<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-12 14:39:16 --> Query error: Unknown column 'data' in 'field list' - Invalid query: SELECT `data`
FROM `vadmin_sessions`
WHERE `id` = '46835d6e4c7070972e07027b80900d58e797db3e'
ERROR - 2015-09-12 14:39:16 --> Query error: Unknown column 'data' in 'field list' - Invalid query: SELECT `data`
FROM `vadmin_sessions`
WHERE `id` = '46835d6e4c7070972e07027b80900d58e797db3e'
ERROR - 2015-09-12 14:41:44 --> Severity: Warning --> require_once(/usr/home/sow/domains/dev2.psychic-contact.com/public_html/application//controllers/popup.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/controllers/chat/ChatInterface.php 3
ERROR - 2015-09-12 14:41:44 --> Severity: Compile Error --> require_once() [<a href='function.require'>function.require</a>]: Failed opening required '/usr/home/sow/domains/dev2.psychic-contact.com/public_html/application//controllers/popup.php' (include_path='.:/usr/local/php5/lib/php') /usr/home/sow/domains/dev2.psychic-contact.com/public_html/application/controllers/chat/ChatInterface.php 3
