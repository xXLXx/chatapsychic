<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-10-29 03:14:30 --> Severity: Warning --> Missing argument 1 for Main::favorite() /usr/home/tst8/domains/chatpsychics.com/public_html/application/controllers/Main.php 114
ERROR - 2015-10-29 03:14:30 --> Severity: Notice --> Undefined variable: profile_id /usr/home/tst8/domains/chatpsychics.com/public_html/application/controllers/Main.php 118
ERROR - 2015-10-29 03:14:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-29 10:05:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-29 16:57:10 --> Severity: Warning --> Missing argument 1 for Main::favorite() /usr/home/tst8/domains/chatpsychics.com/public_html/application/controllers/Main.php 114
ERROR - 2015-10-29 16:57:10 --> Severity: Notice --> Undefined variable: profile_id /usr/home/tst8/domains/chatpsychics.com/public_html/application/controllers/Main.php 118
ERROR - 2015-10-29 16:57:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-29 17:02:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-29 22:05:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-29 23:01:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
