<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-10-30 04:37:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-30 10:42:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-30 10:43:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-30 11:11:38 --> Severity: Warning --> Missing argument 1 for Main::favorite() /usr/home/tst8/domains/chatpsychics.com/public_html/application/controllers/Main.php 114
ERROR - 2015-10-30 11:11:38 --> Severity: Notice --> Undefined variable: profile_id /usr/home/tst8/domains/chatpsychics.com/public_html/application/controllers/Main.php 118
ERROR - 2015-10-30 12:27:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-30 17:15:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-30 19:33:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-10-30 22:50:32 --> Severity: Warning --> Missing argument 1 for Main::favorite() /usr/home/tst8/domains/chatpsychics.com/public_html/application/controllers/Main.php 114
ERROR - 2015-10-30 22:50:32 --> Severity: Notice --> Undefined variable: profile_id /usr/home/tst8/domains/chatpsychics.com/public_html/application/controllers/Main.php 118
ERROR - 2015-10-30 22:50:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
