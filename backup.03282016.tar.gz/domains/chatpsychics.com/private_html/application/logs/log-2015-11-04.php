<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-04 14:58:18 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 14:58:18 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 14:58:32 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 14:58:32 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 14:58:39 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 14:58:39 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 14:59:42 --> Query error: Got error 28 from storage engine - Invalid query: SHOW COLUMNS FROM `blog_comments`
ERROR - 2015-11-04 15:00:03 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:00:03 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:02:25 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:02:25 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:09:29 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:09:29 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:09:57 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:09:57 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:12:06 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 84
ERROR - 2015-11-04 15:12:06 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 84
ERROR - 2015-11-04 15:13:04 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 85
ERROR - 2015-11-04 15:13:04 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 85
ERROR - 2015-11-04 15:13:51 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 82
ERROR - 2015-11-04 15:13:51 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 85
ERROR - 2015-11-04 15:13:51 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 85
ERROR - 2015-11-04 15:13:56 --> Severity: Notice --> Undefined property: CI_Loader::$id /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 82
ERROR - 2015-11-04 15:13:56 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 85
ERROR - 2015-11-04 15:13:56 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 85
ERROR - 2015-11-04 15:14:04 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 82
ERROR - 2015-11-04 15:14:04 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 85
ERROR - 2015-11-04 15:14:04 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 85
ERROR - 2015-11-04 15:17:59 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:17:59 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:18:00 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:18:00 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:52:11 --> Severity: Notice --> Undefined property: CI_Loader::$lb /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:52:11 --> Severity: Error --> Call to a member function config() on a non-object /usr/home/tst8/domains/chatpsychics.com/public_html/application/views/vadmin/overview.php 83
ERROR - 2015-11-04 15:52:59 --> Query error: Got error 28 from storage engine - Invalid query: SHOW COLUMNS FROM `pages`
ERROR - 2015-11-04 16:00:42 --> Query error: Got error 28 from storage engine - Invalid query: SHOW COLUMNS FROM `pages`
ERROR - 2015-11-04 16:20:40 --> Query error: Got error 28 from storage engine - Invalid query: SHOW COLUMNS FROM `pages`
ERROR - 2015-11-04 18:00:03 --> Query error: Got error 28 from storage engine - Invalid query: SHOW COLUMNS FROM `pages`
