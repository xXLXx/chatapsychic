<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-18 06:40:06 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 06:40:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 06:40:06 --> Unable to select database: tst8_main
ERROR - 2015-11-18 06:40:07 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 06:40:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 06:40:07 --> Unable to select database: tst8_main
ERROR - 2015-11-18 06:44:08 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 06:44:08 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 06:44:08 --> Unable to select database: tst8_main
ERROR - 2015-11-18 06:44:35 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 06:44:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 06:44:35 --> Unable to select database: tst8_main
ERROR - 2015-11-18 07:23:23 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 07:23:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 07:23:23 --> Unable to select database: tst8_main
ERROR - 2015-11-18 07:24:55 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 07:24:55 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 07:24:55 --> Unable to select database: tst8_main
ERROR - 2015-11-18 07:41:16 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 07:41:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 07:41:16 --> Unable to select database: tst8_main
ERROR - 2015-11-18 07:41:36 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 07:41:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 07:41:36 --> Unable to select database: tst8_main
ERROR - 2015-11-18 08:19:41 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 08:19:41 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 08:19:41 --> Unable to select database: tst8_main
ERROR - 2015-11-18 08:24:43 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 08:24:43 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 08:24:43 --> Unable to select database: tst8_main
ERROR - 2015-11-18 08:40:36 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 08:40:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 08:40:36 --> Unable to select database: tst8_main
ERROR - 2015-11-18 08:45:53 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 08:45:53 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 08:45:53 --> Unable to select database: tst8_main
ERROR - 2015-11-18 08:46:28 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 08:46:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 08:46:28 --> Unable to select database: tst8_main
ERROR - 2015-11-18 09:20:10 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 09:20:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 09:20:12 --> Unable to select database: tst8_main
ERROR - 2015-11-18 09:25:10 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 09:25:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 09:25:10 --> Unable to select database: tst8_main
ERROR - 2015-11-18 09:41:32 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 09:41:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 09:41:32 --> Unable to select database: tst8_main
ERROR - 2015-11-18 09:44:39 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 09:44:39 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 09:44:39 --> Unable to select database: tst8_main
ERROR - 2015-11-18 09:45:12 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 09:45:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 09:45:12 --> Unable to select database: tst8_main
ERROR - 2015-11-18 10:43:08 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 10:43:08 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 10:43:08 --> Unable to select database: tst8_main
ERROR - 2015-11-18 10:43:41 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 10:43:41 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 10:43:41 --> Unable to select database: tst8_main
ERROR - 2015-11-18 11:18:01 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 11:18:01 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 11:18:01 --> Unable to select database: tst8_main
ERROR - 2015-11-18 11:27:31 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 11:27:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 11:27:31 --> Unable to select database: tst8_main
ERROR - 2015-11-18 11:44:09 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 11:44:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 11:44:09 --> Unable to select database: tst8_main
ERROR - 2015-11-18 11:44:43 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 11:44:43 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 11:44:43 --> Unable to select database: tst8_main
ERROR - 2015-11-18 12:02:44 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 12:02:44 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 12:02:44 --> Unable to select database: tst8_main
ERROR - 2015-11-18 12:02:45 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 12:02:45 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 12:02:45 --> Unable to select database: tst8_main
ERROR - 2015-11-18 12:02:46 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 12:02:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 12:02:46 --> Unable to select database: tst8_main
ERROR - 2015-11-18 12:03:51 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 12:03:51 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 12:03:51 --> Unable to select database: tst8_main
ERROR - 2015-11-18 12:12:01 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 12:12:01 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 12:12:01 --> Unable to select database: tst8_main
ERROR - 2015-11-18 12:16:44 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 12:16:44 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 12:16:44 --> Unable to select database: tst8_main
ERROR - 2015-11-18 12:20:34 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 12:20:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 12:20:34 --> Unable to select database: tst8_main
ERROR - 2015-11-18 12:31:21 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 12:31:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 12:31:21 --> Unable to select database: tst8_main
ERROR - 2015-11-18 12:39:26 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 12:39:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 12:39:26 --> Unable to select database: tst8_main
ERROR - 2015-11-18 12:39:49 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 12:39:49 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 12:39:49 --> Unable to select database: tst8_main
ERROR - 2015-11-18 13:38:08 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 13:38:08 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 13:38:08 --> Unable to select database: tst8_main
ERROR - 2015-11-18 13:38:29 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 13:38:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 13:38:29 --> Unable to select database: tst8_main
ERROR - 2015-11-18 14:16:40 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 14:16:40 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 14:16:40 --> Unable to select database: tst8_main
ERROR - 2015-11-18 14:26:29 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 14:26:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 14:26:29 --> Unable to select database: tst8_main
ERROR - 2015-11-18 14:39:41 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 14:39:41 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 14:39:41 --> Unable to select database: tst8_main
ERROR - 2015-11-18 14:44:08 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 14:44:08 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 14:44:08 --> Unable to select database: tst8_main
ERROR - 2015-11-18 14:44:40 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 14:44:40 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 14:44:40 --> Unable to select database: tst8_main
ERROR - 2015-11-18 15:19:18 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 15:19:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 15:19:18 --> Unable to select database: tst8_main
ERROR - 2015-11-18 15:27:23 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 15:27:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 15:27:23 --> Unable to select database: tst8_main
ERROR - 2015-11-18 15:33:10 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 15:33:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 15:33:10 --> Unable to select database: tst8_main
ERROR - 2015-11-18 15:42:59 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 15:42:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 15:42:59 --> Unable to select database: tst8_main
ERROR - 2015-11-18 15:42:59 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 15:42:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 15:42:59 --> Unable to select database: tst8_main
ERROR - 2015-11-18 15:42:59 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 15:42:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 15:42:59 --> Unable to select database: tst8_main
ERROR - 2015-11-18 15:43:22 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 15:43:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 15:43:22 --> Unable to select database: tst8_main
ERROR - 2015-11-18 15:43:53 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 15:43:53 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 15:43:53 --> Unable to select database: tst8_main
ERROR - 2015-11-18 16:08:25 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 16:08:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 16:08:25 --> Unable to select database: tst8_main
ERROR - 2015-11-18 16:10:15 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 16:10:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 16:10:15 --> Unable to select database: tst8_main
ERROR - 2015-11-18 16:19:12 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 16:19:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 16:19:12 --> Unable to select database: tst8_main
ERROR - 2015-11-18 17:16:59 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 17:16:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 17:16:59 --> Unable to select database: tst8_main
ERROR - 2015-11-18 17:23:42 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 17:23:42 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 17:23:42 --> Unable to select database: tst8_main
ERROR - 2015-11-18 17:39:51 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 17:39:51 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 17:39:51 --> Unable to select database: tst8_main
ERROR - 2015-11-18 17:40:18 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 17:40:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 17:40:18 --> Unable to select database: tst8_main
ERROR - 2015-11-18 18:09:50 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 18:09:50 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 18:09:50 --> Unable to select database: tst8_main
ERROR - 2015-11-18 18:10:15 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 18:10:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 18:10:15 --> Unable to select database: tst8_main
ERROR - 2015-11-18 18:18:41 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 18:18:41 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 18:18:41 --> Unable to select database: tst8_main
ERROR - 2015-11-18 18:26:34 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 18:26:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 18:26:34 --> Unable to select database: tst8_main
ERROR - 2015-11-18 18:47:36 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 18:47:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 18:47:36 --> Unable to select database: tst8_main
ERROR - 2015-11-18 19:20:13 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 19:20:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 19:20:13 --> Unable to select database: tst8_main
ERROR - 2015-11-18 19:20:41 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 19:20:41 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 19:20:41 --> Unable to select database: tst8_main
ERROR - 2015-11-18 19:26:48 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 19:26:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 19:26:48 --> Unable to select database: tst8_main
ERROR - 2015-11-18 20:03:54 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 20:03:54 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 20:03:54 --> Unable to select database: tst8_main
ERROR - 2015-11-18 20:04:20 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 20:04:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 20:04:20 --> Unable to select database: tst8_main
ERROR - 2015-11-18 20:16:20 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 20:16:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 20:16:20 --> Unable to select database: tst8_main
ERROR - 2015-11-18 20:26:08 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 20:26:08 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 20:26:08 --> Unable to select database: tst8_main
ERROR - 2015-11-18 20:41:14 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 20:41:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 20:41:14 --> Unable to select database: tst8_main
ERROR - 2015-11-18 20:43:12 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 20:43:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 20:43:12 --> Unable to select database: tst8_main
ERROR - 2015-11-18 20:43:41 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 20:43:41 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 20:43:41 --> Unable to select database: tst8_main
ERROR - 2015-11-18 20:57:52 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 20:57:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 20:57:52 --> Unable to select database: tst8_main
ERROR - 2015-11-18 21:18:07 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 21:18:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 21:18:07 --> Unable to select database: tst8_main
ERROR - 2015-11-18 21:26:41 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 21:26:41 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 21:26:41 --> Unable to select database: tst8_main
ERROR - 2015-11-18 21:42:29 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 21:42:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 21:42:29 --> Unable to select database: tst8_main
ERROR - 2015-11-18 21:42:52 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 21:42:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 21:42:52 --> Unable to select database: tst8_main
ERROR - 2015-11-18 21:55:23 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 21:55:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 21:55:23 --> Unable to select database: tst8_main
ERROR - 2015-11-18 21:55:23 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 21:55:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 21:55:23 --> Unable to select database: tst8_main
ERROR - 2015-11-18 21:55:24 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 21:55:24 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 21:55:24 --> Unable to select database: tst8_main
ERROR - 2015-11-18 22:18:28 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 22:18:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 22:18:28 --> Unable to select database: tst8_main
ERROR - 2015-11-18 22:26:18 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 22:26:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 22:26:18 --> Unable to select database: tst8_main
ERROR - 2015-11-18 22:42:00 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 22:42:00 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 22:42:00 --> Unable to select database: tst8_main
ERROR - 2015-11-18 22:42:24 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 22:42:24 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 22:42:24 --> Unable to select database: tst8_main
ERROR - 2015-11-18 22:45:23 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 22:45:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 22:45:23 --> Unable to select database: tst8_main
ERROR - 2015-11-18 23:17:31 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 23:17:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 23:17:31 --> Unable to select database: tst8_main
ERROR - 2015-11-18 23:20:50 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 23:20:50 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 23:20:50 --> Unable to select database: tst8_main
ERROR - 2015-11-18 23:35:03 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 23:35:03 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 23:35:03 --> Unable to select database: tst8_main
ERROR - 2015-11-18 23:48:49 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 23:48:49 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 23:48:49 --> Unable to select database: tst8_main
ERROR - 2015-11-18 23:49:21 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-18 23:49:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-18 23:49:21 --> Unable to select database: tst8_main
