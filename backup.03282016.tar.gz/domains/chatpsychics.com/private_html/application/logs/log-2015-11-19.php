<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-19 00:17:50 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 00:17:50 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 00:17:50 --> Unable to select database: tst8_main
ERROR - 2015-11-19 00:21:25 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 00:21:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 00:21:25 --> Unable to select database: tst8_main
ERROR - 2015-11-19 00:36:02 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 00:36:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 00:36:02 --> Unable to select database: tst8_main
ERROR - 2015-11-19 00:41:25 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 00:41:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 00:41:25 --> Unable to select database: tst8_main
ERROR - 2015-11-19 00:41:51 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 00:41:51 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 00:41:51 --> Unable to select database: tst8_main
ERROR - 2015-11-19 01:18:16 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 01:18:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 01:18:16 --> Unable to select database: tst8_main
ERROR - 2015-11-19 01:21:11 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 01:21:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 01:21:11 --> Unable to select database: tst8_main
ERROR - 2015-11-19 01:40:10 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 01:40:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 01:40:10 --> Unable to select database: tst8_main
ERROR - 2015-11-19 01:40:30 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 01:40:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 01:40:30 --> Unable to select database: tst8_main
ERROR - 2015-11-19 02:17:38 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 02:17:38 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 02:17:38 --> Unable to select database: tst8_main
ERROR - 2015-11-19 02:20:46 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 02:20:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 02:20:46 --> Unable to select database: tst8_main
ERROR - 2015-11-19 02:47:33 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 02:47:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 02:47:33 --> Unable to select database: tst8_main
ERROR - 2015-11-19 02:48:12 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 02:48:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 02:48:12 --> Unable to select database: tst8_main
ERROR - 2015-11-19 03:10:12 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 03:10:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 03:10:12 --> Unable to select database: tst8_main
ERROR - 2015-11-19 03:10:12 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 03:10:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 03:10:12 --> Unable to select database: tst8_main
ERROR - 2015-11-19 03:14:19 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 03:14:19 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 03:14:19 --> Unable to select database: tst8_main
ERROR - 2015-11-19 03:14:19 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 03:14:19 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 03:14:19 --> Unable to select database: tst8_main
ERROR - 2015-11-19 03:14:45 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 03:14:45 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 03:14:45 --> Unable to select database: tst8_main
ERROR - 2015-11-19 03:14:45 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 03:14:45 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 03:14:45 --> Unable to select database: tst8_main
ERROR - 2015-11-19 03:18:26 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 03:18:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 03:18:26 --> Unable to select database: tst8_main
ERROR - 2015-11-19 03:21:16 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 03:21:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 03:21:16 --> Unable to select database: tst8_main
ERROR - 2015-11-19 03:49:09 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 03:49:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 03:49:09 --> Unable to select database: tst8_main
ERROR - 2015-11-19 03:49:36 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 03:49:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 03:49:36 --> Unable to select database: tst8_main
ERROR - 2015-11-19 03:55:12 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 03:55:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 03:55:12 --> Unable to select database: tst8_main
ERROR - 2015-11-19 03:55:43 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 03:55:43 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 03:55:43 --> Unable to select database: tst8_main
ERROR - 2015-11-19 04:19:47 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 04:19:47 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 04:19:47 --> Unable to select database: tst8_main
ERROR - 2015-11-19 04:21:59 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 04:21:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 04:21:59 --> Unable to select database: tst8_main
ERROR - 2015-11-19 04:58:10 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 04:58:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 04:58:10 --> Unable to select database: tst8_main
ERROR - 2015-11-19 05:17:39 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 05:17:39 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 05:17:39 --> Unable to select database: tst8_main
ERROR - 2015-11-19 05:20:36 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 05:20:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 05:20:36 --> Unable to select database: tst8_main
ERROR - 2015-11-19 05:36:29 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 05:36:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 05:36:29 --> Unable to select database: tst8_main
ERROR - 2015-11-19 05:37:42 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 05:37:42 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 05:37:42 --> Unable to select database: tst8_main
ERROR - 2015-11-19 05:38:09 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 05:38:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 05:38:09 --> Unable to select database: tst8_main
ERROR - 2015-11-19 05:43:35 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 05:43:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 05:43:35 --> Unable to select database: tst8_main
ERROR - 2015-11-19 05:57:31 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 05:57:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 05:57:31 --> Unable to select database: tst8_main
ERROR - 2015-11-19 05:57:55 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 05:57:55 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 05:57:55 --> Unable to select database: tst8_main
ERROR - 2015-11-19 06:19:18 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 06:19:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 06:19:18 --> Unable to select database: tst8_main
ERROR - 2015-11-19 06:22:57 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 06:22:57 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 06:22:57 --> Unable to select database: tst8_main
ERROR - 2015-11-19 06:51:57 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 06:51:57 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 06:51:57 --> Unable to select database: tst8_main
ERROR - 2015-11-19 06:52:26 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 06:52:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 06:52:26 --> Unable to select database: tst8_main
ERROR - 2015-11-19 07:05:24 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 07:05:24 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 07:05:24 --> Unable to select database: tst8_main
ERROR - 2015-11-19 07:17:33 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 07:17:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 07:17:33 --> Unable to select database: tst8_main
ERROR - 2015-11-19 07:24:30 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 07:24:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 07:24:30 --> Unable to select database: tst8_main
ERROR - 2015-11-19 07:43:55 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 07:43:55 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 07:43:55 --> Unable to select database: tst8_main
ERROR - 2015-11-19 07:44:16 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 07:44:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 07:44:16 --> Unable to select database: tst8_main
ERROR - 2015-11-19 07:59:45 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 07:59:45 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 07:59:45 --> Unable to select database: tst8_main
ERROR - 2015-11-19 08:04:48 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 08:04:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 08:04:48 --> Unable to select database: tst8_main
ERROR - 2015-11-19 08:17:52 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 08:17:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 08:17:52 --> Unable to select database: tst8_main
ERROR - 2015-11-19 08:20:48 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 08:20:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 08:20:48 --> Unable to select database: tst8_main
ERROR - 2015-11-19 08:44:55 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 08:44:55 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 08:44:55 --> Unable to select database: tst8_main
ERROR - 2015-11-19 08:45:27 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 08:45:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 08:45:27 --> Unable to select database: tst8_main
ERROR - 2015-11-19 09:19:14 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 09:19:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 09:19:14 --> Unable to select database: tst8_main
ERROR - 2015-11-19 09:24:12 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 09:24:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 09:24:12 --> Unable to select database: tst8_main
ERROR - 2015-11-19 09:25:01 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 09:25:01 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 09:25:01 --> Unable to select database: tst8_main
ERROR - 2015-11-19 09:42:48 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 09:42:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 09:42:48 --> Unable to select database: tst8_main
ERROR - 2015-11-19 09:43:09 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 09:43:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 09:43:09 --> Unable to select database: tst8_main
ERROR - 2015-11-19 10:19:44 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 10:19:44 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 10:19:44 --> Unable to select database: tst8_main
ERROR - 2015-11-19 10:24:50 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 10:24:50 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 10:24:50 --> Unable to select database: tst8_main
ERROR - 2015-11-19 10:45:41 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 10:45:41 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 10:45:41 --> Unable to select database: tst8_main
ERROR - 2015-11-19 10:46:12 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 10:46:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 10:46:12 --> Unable to select database: tst8_main
ERROR - 2015-11-19 11:18:40 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 11:18:40 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 11:18:40 --> Unable to select database: tst8_main
ERROR - 2015-11-19 11:24:08 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 11:24:08 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 11:24:08 --> Unable to select database: tst8_main
ERROR - 2015-11-19 11:48:36 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 11:48:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 11:48:36 --> Unable to select database: tst8_main
ERROR - 2015-11-19 11:49:13 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 11:49:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 11:49:13 --> Unable to select database: tst8_main
ERROR - 2015-11-19 12:18:55 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 12:18:55 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 12:18:55 --> Unable to select database: tst8_main
ERROR - 2015-11-19 12:24:11 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 12:24:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 12:24:12 --> Unable to select database: tst8_main
ERROR - 2015-11-19 12:38:48 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 12:38:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 12:38:48 --> Unable to select database: tst8_main
ERROR - 2015-11-19 12:39:11 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 12:39:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 12:39:11 --> Unable to select database: tst8_main
ERROR - 2015-11-19 13:19:44 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 13:19:45 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 13:19:45 --> Unable to select database: tst8_main
ERROR - 2015-11-19 13:24:18 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 13:24:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 13:24:18 --> Unable to select database: tst8_main
ERROR - 2015-11-19 13:38:23 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 13:38:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 13:38:23 --> Unable to select database: tst8_main
ERROR - 2015-11-19 13:38:43 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 13:38:43 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 13:38:43 --> Unable to select database: tst8_main
ERROR - 2015-11-19 14:23:27 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 14:23:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 14:23:27 --> Unable to select database: tst8_main
ERROR - 2015-11-19 14:27:10 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 14:27:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 14:27:10 --> Unable to select database: tst8_main
ERROR - 2015-11-19 14:45:56 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 14:45:57 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 14:45:57 --> Unable to select database: tst8_main
ERROR - 2015-11-19 14:46:33 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 14:46:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 14:46:33 --> Unable to select database: tst8_main
ERROR - 2015-11-19 15:24:14 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 15:24:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 15:24:14 --> Unable to select database: tst8_main
ERROR - 2015-11-19 15:27:47 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 15:27:47 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 15:27:47 --> Unable to select database: tst8_main
ERROR - 2015-11-19 15:44:05 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 15:44:05 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 15:44:05 --> Unable to select database: tst8_main
ERROR - 2015-11-19 15:44:31 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 15:44:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 15:44:31 --> Unable to select database: tst8_main
ERROR - 2015-11-19 16:25:46 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 16:25:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 16:25:46 --> Unable to select database: tst8_main
ERROR - 2015-11-19 16:29:06 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 16:29:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 16:29:06 --> Unable to select database: tst8_main
ERROR - 2015-11-19 17:23:59 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 17:23:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 17:23:59 --> Unable to select database: tst8_main
ERROR - 2015-11-19 17:27:15 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 17:27:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 17:27:15 --> Unable to select database: tst8_main
ERROR - 2015-11-19 18:24:54 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 18:24:54 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 18:24:54 --> Unable to select database: tst8_main
ERROR - 2015-11-19 18:28:57 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 18:28:57 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 18:28:57 --> Unable to select database: tst8_main
ERROR - 2015-11-19 18:57:24 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 18:57:24 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 18:57:24 --> Unable to select database: tst8_main
ERROR - 2015-11-19 18:57:28 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 18:57:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 18:57:28 --> Unable to select database: tst8_main
ERROR - 2015-11-19 19:03:21 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 19:03:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 19:03:21 --> Unable to select database: tst8_main
ERROR - 2015-11-19 19:03:46 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 19:03:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 19:03:46 --> Unable to select database: tst8_main
ERROR - 2015-11-19 19:24:35 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 19:24:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 19:24:35 --> Unable to select database: tst8_main
ERROR - 2015-11-19 19:29:00 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 19:29:00 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 19:29:00 --> Unable to select database: tst8_main
ERROR - 2015-11-19 19:48:43 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 19:48:43 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 19:48:43 --> Unable to select database: tst8_main
ERROR - 2015-11-19 19:49:12 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 19:49:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 19:49:12 --> Unable to select database: tst8_main
ERROR - 2015-11-19 20:18:34 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 20:18:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 20:18:34 --> Unable to select database: tst8_main
ERROR - 2015-11-19 20:26:20 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 20:26:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 20:26:20 --> Unable to select database: tst8_main
ERROR - 2015-11-19 21:00:25 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 21:00:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 21:00:25 --> Unable to select database: tst8_main
ERROR - 2015-11-19 21:00:54 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 21:00:54 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 21:00:54 --> Unable to select database: tst8_main
ERROR - 2015-11-19 21:18:46 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 21:18:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 21:18:46 --> Unable to select database: tst8_main
ERROR - 2015-11-19 21:27:31 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 21:27:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 21:27:31 --> Unable to select database: tst8_main
ERROR - 2015-11-19 21:42:06 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 21:42:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 21:42:06 --> Unable to select database: tst8_main
ERROR - 2015-11-19 21:42:30 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 21:42:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 21:42:30 --> Unable to select database: tst8_main
ERROR - 2015-11-19 22:19:22 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 22:19:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 22:19:22 --> Unable to select database: tst8_main
ERROR - 2015-11-19 22:28:55 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 22:28:55 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 22:28:55 --> Unable to select database: tst8_main
ERROR - 2015-11-19 22:43:30 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 22:43:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 22:43:30 --> Unable to select database: tst8_main
ERROR - 2015-11-19 22:43:53 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 22:43:53 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 22:43:53 --> Unable to select database: tst8_main
ERROR - 2015-11-19 23:18:17 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 23:18:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 23:18:17 --> Unable to select database: tst8_main
ERROR - 2015-11-19 23:27:09 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 23:27:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 23:27:09 --> Unable to select database: tst8_main
ERROR - 2015-11-19 23:43:53 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 23:43:53 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 23:43:53 --> Unable to select database: tst8_main
ERROR - 2015-11-19 23:44:23 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 23:44:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 23:44:23 --> Unable to select database: tst8_main
ERROR - 2015-11-19 23:46:09 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 23:46:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 23:46:09 --> Unable to select database: tst8_main
ERROR - 2015-11-19 23:46:43 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-19 23:46:43 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-19 23:46:43 --> Unable to select database: tst8_main
