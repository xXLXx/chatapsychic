<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-20 00:18:21 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-20 00:18:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-20 00:18:21 --> Unable to select database: tst8_main
ERROR - 2015-11-20 00:28:32 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-20 00:28:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-20 00:28:32 --> Unable to select database: tst8_main
ERROR - 2015-11-20 00:47:56 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-20 00:47:56 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-20 00:47:56 --> Unable to select database: tst8_main
ERROR - 2015-11-20 00:50:45 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-20 00:50:45 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-20 00:50:45 --> Unable to select database: tst8_main
ERROR - 2015-11-20 00:51:37 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-20 00:51:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-20 00:51:37 --> Unable to select database: tst8_main
ERROR - 2015-11-20 00:52:04 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-20 00:52:04 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-20 00:52:04 --> Unable to select database: tst8_main
ERROR - 2015-11-20 01:10:13 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-20 01:10:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-20 01:10:13 --> Unable to select database: tst8_main
ERROR - 2015-11-20 01:19:04 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-20 01:19:04 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-20 01:19:04 --> Unable to select database: tst8_main
ERROR - 2015-11-20 01:28:59 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-20 01:28:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-20 01:28:59 --> Unable to select database: tst8_main
ERROR - 2015-11-20 01:38:42 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-20 01:38:42 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-20 01:38:42 --> Unable to select database: tst8_main
ERROR - 2015-11-20 01:39:03 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-20 01:39:03 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-20 01:39:03 --> Unable to select database: tst8_main
ERROR - 2015-11-20 01:47:09 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-11-20 01:47:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-11-20 01:47:09 --> Unable to select database: tst8_main
