<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-08 02:41:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-12-08 09:14:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-12-08 14:48:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
ERROR - 2015-12-08 21:28:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7 - Invalid query: select m.*,
                                             t.*
                                      from   testimonials t,
                                             members m
                                      WHERE  t.member_id = m.id
                                              and t.reader_approved = 1 and admin_approved = 1 
                                             and t.reader_id = 
