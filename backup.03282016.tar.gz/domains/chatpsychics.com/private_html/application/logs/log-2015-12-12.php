<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-12 15:30:07 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 15:30:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 15:30:07 --> Unable to select database: tst8_main
ERROR - 2015-12-12 15:44:58 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 15:44:58 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 15:44:58 --> Unable to select database: tst8_main
ERROR - 2015-12-12 15:45:31 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 15:45:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 15:45:31 --> Unable to select database: tst8_main
ERROR - 2015-12-12 16:20:24 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 16:20:24 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 16:20:24 --> Unable to select database: tst8_main
ERROR - 2015-12-12 16:21:55 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 16:21:55 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 16:21:55 --> Unable to select database: tst8_main
ERROR - 2015-12-12 16:30:34 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 16:30:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 16:30:34 --> Unable to select database: tst8_main
ERROR - 2015-12-12 16:51:16 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 16:51:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 16:51:17 --> Unable to select database: tst8_main
ERROR - 2015-12-12 16:57:25 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 16:57:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 16:57:25 --> Unable to select database: tst8_main
ERROR - 2015-12-12 17:42:13 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 17:42:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 17:42:13 --> Unable to select database: tst8_main
ERROR - 2015-12-12 17:42:28 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 17:42:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 17:42:28 --> Unable to select database: tst8_main
ERROR - 2015-12-12 18:15:20 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 18:15:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 18:15:21 --> Unable to select database: tst8_main
ERROR - 2015-12-12 18:15:35 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 18:15:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 18:15:35 --> Unable to select database: tst8_main
ERROR - 2015-12-12 18:17:36 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 18:17:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 18:17:36 --> Unable to select database: tst8_main
ERROR - 2015-12-12 18:20:13 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 18:20:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 18:20:13 --> Unable to select database: tst8_main
ERROR - 2015-12-12 18:53:45 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 18:53:45 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 18:53:45 --> Unable to select database: tst8_main
ERROR - 2015-12-12 18:54:10 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 18:54:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 18:54:10 --> Unable to select database: tst8_main
ERROR - 2015-12-12 19:19:44 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 19:19:44 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 19:19:44 --> Unable to select database: tst8_main
ERROR - 2015-12-12 19:24:04 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 19:24:04 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 19:24:04 --> Unable to select database: tst8_main
ERROR - 2015-12-12 19:27:40 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 19:27:40 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 19:27:40 --> Unable to select database: tst8_main
ERROR - 2015-12-12 19:28:06 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 19:28:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 19:28:06 --> Unable to select database: tst8_main
ERROR - 2015-12-12 20:00:11 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 20:00:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 20:00:11 --> Unable to select database: tst8_main
ERROR - 2015-12-12 20:02:23 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 20:02:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 20:02:23 --> Unable to select database: tst8_main
ERROR - 2015-12-12 20:20:38 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 20:20:38 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 20:20:38 --> Unable to select database: tst8_main
ERROR - 2015-12-12 20:23:37 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 20:23:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 20:23:37 --> Unable to select database: tst8_main
ERROR - 2015-12-12 20:29:48 --> Severity: Warning --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 20:29:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 20:29:48 --> Unable to select database: tst8_main
ERROR - 2015-12-12 22:53:54 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 22:53:54 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 22:53:54 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 22:53:54 --> Unable to select database: tst8_main
ERROR - 2015-12-12 23:14:15 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:14:15 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:14:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 23:14:15 --> Unable to select database: tst8_main
ERROR - 2015-12-12 23:14:48 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:14:48 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 23:14:48 --> Unable to select database: tst8_main
ERROR - 2015-12-12 23:15:09 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:15:09 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:15:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 23:15:09 --> Unable to select database: tst8_main
ERROR - 2015-12-12 23:17:09 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:17:09 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:17:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 23:17:09 --> Unable to select database: tst8_main
ERROR - 2015-12-12 23:17:16 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:17:16 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:17:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 23:17:16 --> Unable to select database: tst8_main
ERROR - 2015-12-12 23:25:09 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:25:09 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:25:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 23:25:09 --> Unable to select database: tst8_main
ERROR - 2015-12-12 23:27:54 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:27:54 --> Severity: Warning --> mysql_connect(): Access denied for user 'tst8_main'@'localhost' (using password: YES) /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2015-12-12 23:27:54 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /usr/home/tst8/domains/chatpsychics.com/public_html/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2015-12-12 23:27:54 --> Unable to select database: tst8_main
