</div>

      <section>
          <div class="ad-holder text-center"><img src="/media/themes/yello-cool/images/banner-ad.png" alt="" class="img-responsive"></div>
    <div class="ad-holder text-center"><img src="/media/themes/yello-cool/images/certificates.png" alt="" class="img-responsive"></div>
      </section>
  </div> <!-- /container -->

<footer class="footer">

    <div class="text-center footer-links">
        <div class="seperator">&nbsp;</div>
        <ul class="nav">
            <li><a href="/privacy-policy">Privacy Policy</a></li>
            <li><a href="/disclaimer">Disclaimer&Terms</a></li>
            <li><a href="/sitemap">Site Map</a></li>
            <li><a href="/affiliate-program">Affiliate Program</a></li>
            <li><a href="/blog">Blog</a></li>
            <li><a href="/register/choose_membership">Psychic? Create An Account!</a></li>

        </ul>

    </div>

    <div class="copy">
        <p class="text-center">Copyright 2016 Chat-Psychics All rights reserved. <span class="privacy">Cookies and Privacy Policy</span> </p>

    </div>

</footer>
</body>
</html>