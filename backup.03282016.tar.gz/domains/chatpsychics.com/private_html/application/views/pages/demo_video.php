
	<div style='font-size:36px;font-weight:bold;color:#ababab;margin-bottom:25px;'>How It Works</div>
	<div>
		<iframe style='border:none;width:100%;height:350px;' src="<?=$this->settings['video_url']?>"></iframe>
	</div>