
	<h2>QnABids</h2>
			
		<form action='/' method='POST' class="qbidz_block">
		
			<a href='/' class='blue-button submit continue_button'><span>Continue</span></a>
			
			<div class='image'><img src='/media/images/question-icon.gif'></div>
			<div class='title'><span>Ask</span></div>
			<div class='clear'></div>
			
			<div class='description'>
				<span class='data'>Need Answers? Ask a Question.</span>
				<input type='text' name='query' style='width:183px;margin-bottom:10px;' placeholder="What would you like to ask?">
			</div>
			
		</form> <!-- .qbidz_block -->
		
		<div class="qbidz_block">
		
			<a href='/qnabids' class='blue-button continue_button'><span>Continue</span></a>
			
			<div class='image'><img src='/media/images/question-icon.gif'></div>
			<div class='title'><span>Answer</span></div>
			<div class='clear'></div>
			
			<div class='description'>
				<span class='data'>Are you an Expert? Register to Answer.</span>
			</div>
			
		</div> <!-- .qbidz_block -->
		
		<div class="qbidz_block" style='margin-right:0;'>
		
			<a href='/about-qnabids' class='blue-button continue_button'><span>Continue</span></a>
			
			<div class='image'><img src='/media/images/question-icon.gif'></div>
			<div class='title'><span>QnABids</span></div>
			<div class='clear'></div>
			
			<div class='description'>
				<span class='data'>Get real-life advice from our Experts and choose what you want to pay!</span>
			</div>
			
		</div> <!-- .qbidz_block -->
		
		<div class='clear'></div>
		
		<div style='height:50px;'>&nbsp;</div>