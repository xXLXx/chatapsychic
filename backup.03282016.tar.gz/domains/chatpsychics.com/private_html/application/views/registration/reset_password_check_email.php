
    <div class='content_area'>

        <h1>Forgot Password?</h1>

        Please check your email account for an email from Psychic-Contact.com to allow you to reset your password.

    </div>